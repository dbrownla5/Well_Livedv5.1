# Services & Pricing — Overview Page

**Page:** `/services`

---

## HERO

**Eyebrow:** The Well Lived Citizen

**Headline:** Services & Pricing

---

## FOUR-PILLAR GRID

### 01 — Home Organization & Modern Move

**The relief of the room.**

Your home, made to work for how you actually live. For the room that keeps collecting piles, the move that technically happened but never settled, the closet that no longer fits your life, or the spaces where everyday friction quietly steals time.

**$150/hr · 3 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book your session → ]** /services/home-organization

---

### 02 — Legacy Planning & Inventory Catalog

**Clarity without fear.**

The operational side of a home, made visible again. This is for the part of life most people don't realize has been quietly building for years — the things inside a home that became part of how life worked, long before anyone stopped to look at them. Not the will. Not the paperwork. Not the part a lawyer handles. The part that lives inside the walls.

**$175/hr · 2 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book your time → ]** /services/legacy

---

### 03 — House Calls

**For the things life leaves unfinished.**

For when the issue isn't the room — it's the person you used to have to call. Possibly my favorite service, and the spirit of this company. Route-based quick asks often absorbed into existing travel days.

**$175/hr · 2 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book me → ]** /services/house-calls

---

### 04 — Curated Resale & Consignment

**Trust-forward thoughtful curation.**

For the things that still have value, story, or second-market potential — without asking you to become a part-time reseller. No item count minimum. Fill what you have and send it when it's ready.

**Commission-based · agreement required**
*Commission structure and full terms covered on the [Pricing page](/pricing).*

**[ Schedule it → ]** /services/resale

---

## CLOSING

**Not sure where to start? Start with what is most real right now.**

Most clients naturally move between these four services over time, and the work is designed to follow real life instead of forcing you into a rigid category.

**[ Get in Touch ]** /contact

---

## FOOTER
*See build plan*

---

v043026
