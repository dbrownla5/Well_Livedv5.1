# Rebuild Plan & Build Order — The Well Lived Citizen

**For:** Whichever deployer Dayna picks (Lovable, Base44, Manus, etc.)
**Source merge:** Replit GitHub repo `dbrownla5/Well_Livedv5.1` + structural changes
**Date stamp:** v043026

---

## NAMING — FIXED

- **Business name:** The Well Lived Citizen *(no "Co." anywhere — hard rule)*
- **Live domain:** thewelllivedcitizen.com
- **Old domain (301 only):** thewelllivedcitizenco.com → thewelllivedcitizen.com
- **Email:** dayna@thewelllivedcitizen.com
- **Phone:** (323) 433-1350
- **Legal entity in footer:** Well Dressed Citizen LLC
- **Founded:** EST. 2020
- **Tagline "Well Kept. Well Placed. Well Lived." is RETIRED** — never use anywhere

---

## SITE MAP

```
/                                    homepage
/services                            all-services overview
/services/home-organization          detail page
/services/legacy                     detail page
/services/house-calls                detail page
/services/resale                     detail page
/pricing                             full pricing + payment terms + cancellation + resale terms
/about                               Dayna bio
/contact                             intake form
```

301 redirects:
- thewelllivedcitizenco.com/* → thewelllivedcitizen.com/*
- www.thewelllivedcitizenco.com/* → thewelllivedcitizen.com/*

Sitemap.xml lists all 9 routes. No /qa or dev routes.

---

## NAV — DROPDOWN STRUCTURE

Top-level:
- Logo → /
- **Services ▾** (dropdown)
- **About**
- **Get in Touch** (CTA-styled)

Services dropdown:
- All Services & Pricing → /services
- Home Organization & Modern Move → /services/home-organization
- Legacy Planning & Inventory Catalog → /services/legacy
- House Calls → /services/house-calls
- Curated Resale & Consignment → /services/resale
- View Pricing → /pricing

Mobile: hamburger drawer, same items, expandable Services group.

**Service detail pages are full standalone pages — not anchor links on /services.**

---

## HOMEPAGE STRUCTURE

1. Hero — copy in `01_homepage_v043026.md`
2. Three Offers Band *(leads the page — not below service pillars)*
3. Transition divider
4. Four Service Pillars *(each links to its detail page)*
5. Testimonial — Gayle, Seattle Client
6. Closing CTA — "Start anywhere."
7. Footer

---

## CONTENT FILES — USE VERBATIM

| Page | Source file |
|---|---|
| `/` | `01_homepage_v043026.md` |
| `/services` | `02_services_overview_v043026.md` |
| `/services/home-organization` | `03_home_organization_v043026.md` |
| `/services/legacy` | `04_legacy_v043026.md` |
| `/services/house-calls` | `05_house_calls_v043026.md` |
| `/services/resale` | `06_resale_v043026.md` |
| `/pricing` | `07_pricing_v043026.md` |
| `/contact` | `08_contact_v043026.md` |
| `/about` | `09_about_v043026.md` |

**Do not rewrite. Do not polish. Use verbatim.**

---

## INTAKE FORM — BRANCHING LOGIC

One form on `/contact`, reused across the site via URL params.

All "Book Now / Schedule it / Book me / Get in Touch" buttons route to `/contact` with optional param (e.g. `/contact?service=home-org`, `/contact?offer=4hour`) so the form pre-selects.

```
Step 1: New / Returning / Referred
   ↓
Step 2 (branches):
   New        → call / book / pickup / not-sure
   Returning  → re-book / pickup / question / talk-first
   Referred   → who referred + what need
   ↓
Step 3 (only if booking): Which service?
   ↓
Step 4: Urgency
   ↓
Step 5: Contact info
   ↓
Step 6: "What's the real-life version?"
   ↓
Step 7: Best time to reach
   ↓
Conditional Calendar Embed: Calendly link (placeholder div — wired by Dayna last)
   ↓
Submit
```

Form backend: Formspree `xreojkvo`. Test submissions reach `dayna@thewelllivedcitizen.com`.

---

## FOOTER — LOCKED

```
[logo]   [Services]  [Pricing]  [About]  [Get in Touch]

The Well Lived Citizen
Los Angeles, CA
Well Dressed Citizen LLC

[IG main]  [IG closet]  [FB]
 MAIN       CLOSET       FB

© 2026 The Well Lived Citizen · Los Angeles, CA
```

Social:
- MAIN → instagram.com/thewelllivedcitizen
- CLOSET → instagram.com/thewelllivedcitizencloset
- FB → facebook.com/thewelllivedcitizen

---

## DESIGN BASELINE

Pull from existing Replit visual styling. Do not redesign.

- **Font:** Plus Jakarta Sans (Google Fonts)
- **Palette:**
  - cream: `#F5F0E8`
  - warm: `#FAF7F2`
  - linen: `#EDE7DB`
  - charcoal: `#1C1917`
  - rust: `#9A5B3C`
  - stone: `#57534E`
- Hanger logo: black on cream + white on dark variants
- Floating "Call or Text" button bottom-right on mobile → tel:3234331350

---

## SEO

- GA4 tag: `G-HN9C986JLW` on every page
- Canonical: `https://thewelllivedcitizen.com[path]` on every page
- robots meta: `index, follow`
- robots.txt: Allow all, declare sitemap
- Schema.org LocalBusiness JSON-LD on homepage: email, phone, LA CA, founder Dayna Brown
- All canonicals use thewelllivedcitizen.com — never the .co domain
- Never use "Special Delivery," "elder care," or "estate sale" anywhere

---

## IMAGERY RULES

- Logo (provided)
- Dayna portrait (provided `/images/dayna.jpg`)
- **NO AI-generated imagery**
- **NO stock photography**
- If no image is provided for a slot, leave empty or use a typographic block

---

## SANITY CMS — FULL ARCHITECTURE

**Stack:** Next.js (App Router) + Sanity (Embedded Studio)
**Pattern:** Page Builder (arrays of block objects)
**Deployment:** Cloudflare Pages (see existing DEPLOY.md) or Vercel

### Project Structure

```
well-lived-citizen/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout — SanityLive + VisualEditing here
│   │   ├── studio/[[...tool]]/
│   │   │   └── page.tsx            # Embedded Studio route
│   │   ├── (site)/
│   │   │   ├── page.tsx            # /
│   │   │   ├── services/
│   │   │   │   ├── page.tsx        # /services
│   │   │   │   ├── home-organization/page.tsx
│   │   │   │   ├── legacy/page.tsx
│   │   │   │   ├── house-calls/page.tsx
│   │   │   │   └── resale/page.tsx
│   │   │   ├── pricing/page.tsx
│   │   │   ├── about/page.tsx
│   │   │   └── contact/page.tsx
│   │   └── api/
│   │       ├── draft-mode/enable/route.ts
│   │       └── revalidate/tag/route.ts
│   └── sanity/
│       ├── lib/
│       │   ├── client.ts
│       │   ├── live.ts             # defineLive setup
│       │   ├── token.ts
│       │   └── queries.ts
│       └── schemaTypes/
│           ├── index.ts
│           ├── documents/
│           │   ├── page.ts
│           │   └── servicePage.ts
│           ├── blocks/
│           │   ├── heroType.ts
│           │   ├── offersType.ts
│           │   ├── servicePillarsType.ts
│           │   ├── pricingTableType.ts
│           │   ├── bundleAddOnsType.ts
│           │   ├── testimonialType.ts
│           │   ├── ctaType.ts
│           │   └── policyType.ts
│           ├── objects/
│           │   ├── pricingRow.ts
│           │   ├── bundleItem.ts
│           │   └── seoFields.ts    # shared SEO fields
│           └── shared/
│               └── seoFields.ts
├── sanity.config.ts
├── sanity.cli.ts
├── sanity.blueprint.ts             # Blueprints IaC (webhooks, CORS, datasets)
└── sanity.types.ts                 # Generated by TypeGen
```

### Block Schema Map

| Block type | Pages | Use objects or refs |
|---|---|---|
| `hero` | All pages | object |
| `offers` | Homepage | object (3 offer blocks, unique per page) |
| `servicePillars` | Homepage, /services | object |
| `serviceDetail` | 4 service detail pages | object |
| `pricingTable` | /pricing, service pages | object |
| `bundleAddOns` | /pricing, /services/home-organization | object |
| `testimonial` | Homepage | reference (reused) |
| `cta` | All pages | object (page-specific variants) |
| `policySection` | /pricing | object |

**Rule:** Default to objects. Use references only for testimonials — they may be reused across pages.

### Schema Rules (from schema skill file)

**Model data, not presentation:**
- ❌ `bigHeroText`, `threeColumnRow`, `redButton`
- ✅ `heroStatement`, `featuresSection`, `callToAction`

**Always use strict definition syntax:**
```typescript
import { defineType, defineField, defineArrayMember } from 'sanity'

export const heroType = defineType({
  name: 'hero',
  type: 'object',
  fields: [
    defineField({ name: 'eyebrow', type: 'string' }),
    defineField({ name: 'headline', type: 'string', validation: r => r.required() }),
    defineField({ name: 'subhead', type: 'text' }),
    defineField({ name: 'body', type: 'array', of: [defineArrayMember({ type: 'block' })] }),
  ],
  preview: {
    select: { title: 'headline' },
    prepare({ title }) {
      return { title: title || 'Untitled Hero', subtitle: 'Hero' }
    }
  }
})
```

**Always use icons from `@sanity/icons`** — assign to every document and block type.

**Shared SEO fields** — spread into every page document:
```typescript
// shared/seoFields.ts
export const seoFields = [
  defineField({ name: 'seoTitle', type: 'string' }),
  defineField({ name: 'seoDescription', type: 'text', validation: r => r.max(160) }),
]
```

**Never store heading levels in schema** — determine dynamically in frontend via `semanticLevel` prop.

**Always include `_key` in array projections:**
```groq
pageBuilder[]{
  _key,
  _type,
  ...
}
```

### Content Migration from Markdown Files

Use `@portabletext/block-tools` + JSDOM to import the nine `.md` content files into Sanity at setup:

```bash
npm install @portabletext/block-tools jsdom
```

```typescript
// migrations/import-site-content/index.ts
import { defineMigration, createOrReplace } from 'sanity/migrate'
import { htmlToBlocks } from '@portabletext/block-tools'
import { JSDOM } from 'jsdom'

export default defineMigration({
  title: 'Import Well Lived Citizen site content',
  async *migrate(documents, context) {
    // For each of the 9 markdown pages, parse and yield a Sanity document
    // Map markdown sections → pageBuilder blocks
    // e.g. ## HERO → heroType block, ## PRICING → pricingTable block
    for (const page of pages) {
      yield createOrReplace({
        _id: page.slug,
        _type: 'page',
        title: page.title,
        pageBuilder: page.blocks,
      })
    }
  }
})
```

Run: `sanity migration run import-site-content --no-dry-run`

### Data Fetching (Next.js)

Use `defineLive` for all data fetching — handles caching and Visual Editing automatically:

```typescript
// sanity/lib/live.ts
import { defineLive } from 'next-sanity'
import { client } from './client'

export const { sanityFetch, SanityLive } = defineLive({
  client: client.withConfig({ apiVersion: '2026-02-01' }),
  serverToken: process.env.SANITY_API_READ_TOKEN,
  browserToken: process.env.SANITY_API_READ_TOKEN,
})
```

**Root layout must include `<SanityLive />`:**
```typescript
// app/layout.tsx
import { SanityLive } from '@/sanity/lib/live'
import { VisualEditing } from 'next-sanity/visual-editing'
import { draftMode } from 'next/headers'

export default async function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
        <SanityLive />
        {(await draftMode()).isEnabled && <VisualEditing />}
      </body>
    </html>
  )
}
```

**Stega — always clean values used in logic:**
```typescript
import { stegaClean } from '@sanity/client/stega'
// Before: if (align === 'center') — breaks in Edit Mode
// After:
const cleanAlign = stegaClean(align)
```

**SEO metadata — always disable stega:**
```typescript
export async function generateMetadata({ params }) {
  const { data } = await sanityFetch({
    query: SEO_QUERY,
    params: await params,
    stega: false  // critical — never let stega chars into <head>
  })
  return { title: data?.title }
}
```

### Page Builder Rendering

```typescript
export function PageBuilder({ content, documentId }: { content: Block[]; documentId: string }) {
  if (!Array.isArray(content)) return null
  return (
    <main>
      {content.map((block) => {
        switch (block._type) {
          case 'hero':      return <Hero key={block._key} documentId={documentId} {...block} />
          case 'offers':    return <Offers key={block._key} documentId={documentId} {...block} />
          case 'servicePillars': return <ServicePillars key={block._key} documentId={documentId} {...block} />
          case 'pricingTable':   return <PricingTable key={block._key} documentId={documentId} {...block} />
          case 'testimonial':    return <Testimonial key={block._key} documentId={documentId} {...block} />
          case 'cta':       return <CTA key={block._key} documentId={documentId} {...block} />
          default:          return <div key={block._key}>Unknown block: {block._type}</div>
        }
      })}
    </main>
  )
}
```

**Always use `block._key` as React key — never array index.**

### Tag-Based Revalidation (webhook)

```typescript
// app/api/revalidate/tag/route.ts
import { revalidateTag } from 'next/cache'
import { parseBody } from 'next-sanity/webhook'

export async function POST(req) {
  const { isValidSignature, body } = await parseBody(req, process.env.SANITY_REVALIDATE_SECRET, true)
  if (!isValidSignature) return new Response('Invalid signature', { status: 401 })
  body.tags.forEach(tag => revalidateTag(tag))
  return Response.json({ revalidated: body.tags })
}
```

Sanity webhook config:
- Filter: `_type in ["page", "servicePage"]`
- Projection: `{ "tags": [_type, _type + ":" + slug.current] }`

### Sanity Blueprints (IaC)

Use `sanity.blueprint.ts` to declare and version-control CORS origins, webhooks, and datasets:

```bash
sanity blueprints init well-lived-citizen
sanity blueprints plan    # preview changes
sanity blueprints deploy  # apply
```

Track in git. Deploy with the site. Webhooks declared here are reproducible across environments.

### Draft Mode

```typescript
// app/api/draft-mode/enable/route.ts
import { defineEnableDraftMode } from 'next-sanity/draft-mode'
import { client } from '@/sanity/lib/client'
import { token } from '@/sanity/lib/token'

export const { GET } = defineEnableDraftMode({
  client: client.withConfig({ token }),
})
```

### Embedded Studio Route

```typescript
// app/studio/[[...tool]]/page.tsx
import { NextStudio } from 'next-sanity/studio'
import config from '../../../../sanity.config'

export const dynamic = 'force-static'
export { metadata, viewport } from 'next-sanity/studio'

export default function StudioPage() {
  return <NextStudio config={config} />
}
```

### Safe Schema Updates

**Never delete a field with production data.** Use the deprecation lifecycle:
1. Add `deprecated: { reason: '...' }` and `readOnly: true`
2. Add `hidden: ({ value }) => value === undefined`
3. Run migration to move data to new field
4. Remove field definition only after all documents are migrated

### TypeGen

Add to `sanity.cli.ts` for type-safe queries. Run `npm run typegen` after schema changes. Output: `sanity.types.ts`.

---

## QA CHECKLIST BEFORE LAUNCH

- [ ] All 9 pages live, all internal links work, no 404s
- [ ] Old domain 301 → new domain
- [ ] Contact form delivers to dayna@thewelllivedcitizen.com (real test submission)
- [ ] Calendly embed loaded and bookable
- [ ] All `tel:` links dial (323) 433-1350
- [ ] All `mailto:` go to dayna@thewelllivedcitizen.com
- [ ] MAIN / CLOSET / FB social links open correct accounts in new tab
- [ ] Floating "Call or Text" button works on mobile
- [ ] Zero instances of "The Well Lived Citizen Co." anywhere
- [ ] Zero "Well Kept. Well Placed. Well Lived."
- [ ] Zero "Special Delivery"
- [ ] Zero "elder care" or "estate sale"
- [ ] stega: false on all SEO/metadata fetches
- [ ] _key used as React key everywhere (never array index)
- [ ] SanityLive rendered in root layout
- [ ] VisualEditing renders in draft mode
- [ ] Webhook wired and tested (tag revalidation fires on publish)
- [ ] Blueprints deployed (CORS, webhooks, dataset confirmed)
- [ ] TypeGen types generated and committed
- [ ] GA4 fires on every page
- [ ] Sitemap.xml lists 9 correct routes

---

v043026
