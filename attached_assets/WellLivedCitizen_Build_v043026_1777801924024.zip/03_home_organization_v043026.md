# Home Organization & Modern Move — Service Page

**Page:** `/services/home-organization`

---

## HERO

**Eyebrow:** 01 — Home Organization & Modern Move

**Headline:** The relief of the room.

**Subhead:** Your home, made to work for how you actually live. For the room that keeps collecting piles, the move that technically happened but never settled, the closet that no longer fits your life, or the spaces where everyday friction quietly steals time.

---

## INTRO

The issue here is the space itself. The room, layout, volume, or systems are no longer supporting the way you naturally move through your day. I come in, find the friction, and make the space work around your real habits.

---

## HOW WE CAN WORK TOGETHER

Projects can be:

- Side-by-side guided sessions
- Hybrid decision blocks
- Full key handoff
- Solo resets while you're away
- Packing and move prep with or without you
- Closet and system continuity after landing

*The right style is the one that creates the easiest lasting outcome.*

---

## WHAT'S INCLUDED

- Intake call, prior coordination, and any pre-planning on my end
- Layout logic
- Sourcing recommendations
- Setup and install
- Label systems
- Pre-order coordination
- Workflow tools and install basics
- Measuring tools, reusable sort bins
- Cord wraps, Velcro, adapters, and utility hardware
- Problem-solving tools that become necessary once the room opens up

For deeper spaces like closets, offices, storage rooms, and linen systems, product support is quoted after walkthrough based on hidden volume and actual dimensions.

---

## PRICING

| | |
|---|---|
| Hourly | $150/hr · 3 hr minimum |
| 10-hour Flex Block | $1,250 |
| 25-hour Flex Block | $3,150 |
| Studio / 1BR Move Reset | $1,200/day flat rate — up to 8 hours straight |
| Larger homes & multi-room projects | Quoted after call |

Flex blocks never expire. $1,200 flat rate is reserved for studio and 1-bedroom moves only. Larger homes scope as projects.

---

## A NOTE ON LABELS

Labels are always included — handwritten on-site by default, and printed sets provided for larger project scopes.

For efficiency, printed labels are usually handled as office work rather than billed hourly. I notate during the session, build the label set in my own app on my own time, print them, and bring them back to apply on the next visit or at the end of a multi-session project. This saves real money on hourly time that would otherwise be spent typing, cutting, and feeding a label maker in the middle of active organizing work.

If you want fully printed labels applied the same day, I'm happy to bring the label maker on-site — just let me know during intake so it's built into the time estimate.

---

## ADD-ONS — FIRST-NIGHT & FIRST-WEEK SUPPLY BUNDLES

Optional product budgets added to any move session or day rate so the home works before the first Target run.

**$150 — Essentials Landing**
Toilet paper, paper towels, basic utensils, water glasses, a wine or whiskey tumbler, laundry and dish detergent, trash bags, trash bins, two bath towels, and two kitchen towels. The first-night basics so nothing has to be bought in a panic.

**$250 — Start-Up Landing**
Everything in Essentials, plus a starter dish set, dish soap, hamper, hangers, and entry-point setup (keys, mail, shoes, bag drop). Enough to make the kitchen functional and the front door feel like a real landing zone.

**$500 — Full Landing Bundle**
Everything in Start-Up, plus sheets, pillows, a steamer, and a duvet. The sleep, shower, eat, charge, and get dressed tonight bundle. Ideal for new-city arrivals, life transitions, furnished rentals, post-breakup moves, and temporary homes that still need to feel fully functional.

---

## ADD-ONS — PRE-BUY ORG BUNDLES

Optional product budgets for clients who want to front-load organizing supplies into the session. Bundles are adjusted based on intake to fit the specific room or project. Any item can be swapped for another of equal value.

**$150 — Starter Org Bundle**
5 bins, 3 bin latches, and a rolling cart. Good for a single closet, pantry shelf, or one focused zone.

**$250 — Mid Org Bundle**
10 bins in mixed sizes, 6 bin latches, a rolling cart, 2 drawer divider sets, and a shelf riser or two. Covers a full closet, a small pantry, or a bathroom + linen combo.

**$500 — Full Org Bundle**
20 bins across multiple sizes, full latch set, rolling cart, 4 drawer divider sets, shelf risers, under-shelf baskets, hanger refresh (slim velvet or wood), and a starter set of clear canisters or lazy susans for pantry or bath. Covers a full pantry, a primary closet + dresser, or a multi-zone reset in one session.

---

## CTA

**[ BOOK YOUR SESSION ]** /contact?service=home-org

← All Services

---

v043026
