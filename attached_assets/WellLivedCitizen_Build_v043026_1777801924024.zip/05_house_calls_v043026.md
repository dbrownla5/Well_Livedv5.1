# House Calls — Service Page

**Page:** `/services/house-calls`

---

## HERO

**Eyebrow:** 03 — House Calls

**Headline:** For the things life leaves unfinished.

**Subhead:** For when the issue isn't the room — it's the person you used to have to call.

---

## INTRO

*Possibly my favorite service, and the spirit of this company.*

The world changed, the process got heavier, and no one can be expected to keep up with every new layer alone. House Calls fills the missing person role in real life: the partner who handled it, the nearby parent, the neighbor, the adult child in another city, the friend who always knew how to make the day still work.

As we get more efficient, this gap gets harder to navigate. Solving it is something I may be able to do for everyone eventually — but right now, the need is there for each person I can reach.

Once I know how your home works, it becomes easy for me to help keep it working — home check-ins, tech setup, hands-on home improvements, donation drop-offs, and the practical loose ends that make everyday life easier when someone trusted is paying attention.

---

## WHO HOUSE CALLS IS FOR

For the people who suddenly find themselves handling the parts of home life someone else used to quietly carry.

The bill that used to auto-resolve because your partner handled it. The appliance install that feels different when you're home alone. The digital login that somehow became intimidating overnight. The package, pickup, repair, donation, or appointment that shouldn't be a big deal but suddenly feels heavier than it should.

**House Calls exists for the private, practical things people don't always want to say out loud.**

The goal is not to make life look perfect. The goal is to make everyday life feel safe, manageable, and less isolating when the normal support system changed.

- Newly divorced
- Recently widowed
- First time living alone
- Partner travels constantly
- Adult children supporting from another city
- Practical aftermath no one stays to help with
- Moments where the original plan stopped working and you still need the day to happen

---

## WAYS TO USE HOUSE CALLS

- One-time practical resets
- Weekly support
- Monthly continuity
- Seasonal resets
- Remote family check-ins
- Post-project upkeep
- Vendor days
- Donation and return routing
- Home re-entry after travel
- Guest and event resets
- The 4-hour practical reset

---

## REAL-LIFE EXAMPLE *(warm panel, rust eyebrow)*

**REAL-LIFE EXAMPLE**

The 8-month pregnant woman with a beautiful baby shower, hundreds of gifts, duplicate baby gear, no time, and no energy to turn a mountain of love into something functional.

I step in for the 4-hour practical reset:

- Unwrap and sort everything
- Organize by month / size / first-use timeline
- Separate immediate essentials
- Identify duplicates
- Create return and resale routes
- Donate what will never realistically be used
- Clear packaging and gift-wrap chaos
- Order thank-you cards
- Export addresses to print
- Reset the room so it actually works for day one

The point is simple: everyone helps celebrate the moment — I help make it livable afterward. That's House Calls.

---

## VENDOR & PROJECT OVERSIGHT

When needed, House Calls also covers:

- Movers
- Haulers
- Cleaners
- Installers
- Contractors
- Storage teams
- Donation pickups
- Resale buyer coordination
- Shipping and courier
- Building and concierge protocol
- Service appointment access

---

## SERVICE AREA

LA base but not radius-limited. Travel by project logic, with route-based efficiency and stops built into the flow. Quick asks can often be absorbed into an existing route. Urgent timing and transition-sensitive requests are prioritized whenever possible.

---

## PRICING

| | |
|---|---|
| Hourly | $175/hr · 2 hr minimum |
| Continuity Retainer | $500/mo |

No membership. No subscription. Ease comes from relationship, not a forced plan.

---

## CLOSING LINE

*Sometimes there isn't a perfect way around the problem. There's just the person who knows how to make the day work anyway. That's where House Calls is most useful.*

---

## CTA

**[ BOOK ME ]** /contact?service=house-calls

← All Services

---

v043026
