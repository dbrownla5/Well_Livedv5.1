# Homepage — The Well Lived Citizen

**Page:** `/` (index)
**Domain:** thewelllivedcitizen.com

---

## NAV
*See build plan*

---

## HERO

**Eyebrow:** Los Angeles

**Headline:** When *"there has to be an easier way"* becomes a business.

**Subhead:** Welcome to the concierge for the things you don't want to handle.

**Body:** My daily life already runs on shipping, logistics, tech fixes, resale, and the kind of real-world problem solving that doesn't slow down. I move fast where things are solvable, and when life gets stuck, I know how to move it through.

**Kicker:** **I'm built for your chaos.**

*(No CTA buttons under the hero. The hero rolls directly into the offers band.)*

---

## OFFERS BAND

Three offer blocks. Each has its own micro-block, price line, single button. Order matters: easiest entry first.

### Offer 1 — The 4-Hour

Book the 4-Hour for the room, task list, move landing, or household overflow that needs to stop catching immediately.

**$500 · This week**

**[ BOOK NOW ]** → /contact?offer=4hour

---

### Offer 2 — Resale Bag Pickup

Moving, closet cleanout, post-breakup, wardrobe reset. Fill 2 to 4 bags and get them to me same day.

Same-day pickup or courier handoff available.

**[ SCHEDULE PICKUP ]** → /contact?offer=pickup

---

### Offer 3 — Need to leave before everything is packed?

You go to the new city, the family home, the furnished rental, or the next place first. I stay behind to pack and close out the space, move what should store, route what should sell, ship what you still need in labeled boxes. Start with a scoped project fee built from hourly work blocks. The move continues in flexible chunks without you carrying the urgency from the other end.

**[ BOOK THE CLOSEOUT ]** → /contact?offer=closeout

---

*divider*

---

## SERVICE PILLARS

Each pillar: number + tagline + body paragraphs + hourly + flex note + CTA. Each links to its own detail page.

### 01 — Home Organization & Modern Move

**Your home, made to work for how you actually live.**

We cover the rooms and spaces. For the room that keeps collecting piles. The storage unit that keeps increasing rent and you only go every six months to ensure you weren't broken into or to take out that one outfit, or bike. The move where the boxes made it through the door, but nothing feels settled. The move where you had to leave before everything was fully packed, and someone still needs to close out what's left behind.

The professional landing in Los Angeles the same day as their boxes and the first day on the job — knowing you'll come home to a boxed mattress, no phone charger, and a suit that needs steaming. No energy, takeout food, or forks. It's the "oh my gosh, someone save me" situation. But you're happy — life is starting a new chapter — you just have to move through the hurdles of that part.

The closet that no longer fits your life, body, season, or the way you actually get dressed (morning or afternoon — no judgment). I come in, find the friction, and make the space work around how you naturally move through your day. The goal is a home that lands well and WORKS and keeps working after I leave.

**$150/hr · 3 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book your session → ]** /services/home-organization

---

### 02 — Legacy Planning & Inventory Catalog

**Clarity without fear.**

The lived-in layer of your home — the walls you spend your life within — needs clarity before it becomes a burden to you, your future self, your family, or the people you rely on. Most people are prepared for the things we're pressured to check off the list — good job, us. You may already have the estate planner, the will, and the paperwork.

My work is the home itself — identifying what's still in use, what still has value (often hidden in cabinets), and what needs a clear plan while you can still decide what matters. When story matters, I document that too — so meaning isn't lost when objects change hands.

I am not a legal estate planner or estate sale service. I focus on the meaning behind the life in your objects and how to preserve that, giving everything more value to you now, your family later, and the people who want your things. You have meaningful things attached to you — let's share them.

**$175/hr · 2 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book your time → ]** /services/legacy

---

### 03 — House Calls

**For the things life leaves unfinished.**

Possibly my favorite service, and the spirit of this company.

That's the thing friends used to do. The thing neighbors don't always have time for anymore. The thing adult children need when they're in another city.

Once I know how your home works, it becomes easy for me to help keep it working — home check-ins, tech setup, hands-on home improvements, donation drop-offs, and the practical loose ends that make everyday life easier when someone trusted is paying attention.

**$175/hr · 2 hr minimum**
*Flex pricing and project quotes covered on the [Pricing page](/pricing).*

**[ Book me → ]** /services/house-calls

---

### 04 — Curated Resale & Consignment

**Is it cool? Is it sellable? Will they even take it?**

This is for clothing, designer bags, jewelry, and the pieces you know might still have value but do not want to spend hours platform-matching, measuring, negotiating, and managing yourself. With an established luxury and resale background, I go through it piece by piece, decide what is worth the effort, and match each item to the platform where it makes the most sense. Clean, non-sellable items can be responsibly donated as part of the process.

You fill the waterproof bag, sign the agreement, and I handle the rest — pickup, styling, measurements, listing, buyer questions, returns, monthly check-ins, and payout on the agreed split.

**Commission-based · agreement required**
*Commission structure and full terms covered on the [Pricing page](/pricing).*

**[ Schedule it → ]** /services/resale

---

*divider*

---

## TESTIMONIAL

> "I wake up and my clicker for all my lamps is on my bedside table. I get up and move it to the dresser by the door so every time I come back in I can turn any lamp from the doorway. My clothes are arranged by item and color, my purses on two long shelves and two short ones — I can see what I have and choose accordingly. My shoes are on four shelves where I can easily see them. The heat is set perfectly. The TV is set up with only one clicker to get to all the channels I want. Thank you for making life easier for me."

— **Gayle, Seattle Client**

---

## CLOSING CTA — DARK BAND

**NOT SURE WHERE TO START?**

# Start anywhere.

No pressure. The whole point is to make your life easier to navigate from here.

**[ GET IN TOUCH ]** /contact

---

## FOOTER
*See build plan*

---

v043026
