(function () {
  function applyInfo(info) {
    document.querySelectorAll("[data-info]").forEach(function (el) {
      var key = el.getAttribute("data-info");
      var val = info[key];
      if (val == null || val === "") return;
      el.textContent = val;
    });
    document.querySelectorAll("[data-info-href]").forEach(function (el) {
      var spec = el.getAttribute("data-info-href");
      // format: "scheme:keyName" e.g. "tel:primaryPhoneRaw" or "sms:zellePhoneRaw" or "mailto:zelleEmail" or "url:stripePaymentLink"
      var parts = spec.split(":");
      var scheme = parts[0];
      var key = parts[1];
      var val = info[key];
      if (val == null || val === "") return;
      var href;
      if (scheme === "url") href = val;
      else if (scheme === "tel" || scheme === "sms") href = scheme + ":" + val;
      else if (scheme === "mailto") href = "mailto:" + val;
      else return;
      el.setAttribute("href", href);
    });
  }

  fetch("/api/business-info", { headers: { Accept: "application/json" } })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (info) { if (info) applyInfo(info); })
    .catch(function () { /* leave fallbacks in place */ });
})();
