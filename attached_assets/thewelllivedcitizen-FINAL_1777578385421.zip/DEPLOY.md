# DEPLOY — The Well Lived Citizen

This is your site. Manus's design, Manus's copy, free hosting on Cloudflare Pages.

## What you need

- A Cloudflare account (free). If you already have one because your domains are there, use that. Log in at https://dash.cloudflare.com/
- The `site/` folder from this zip. Leave it on your desktop.

## The 8 clicks

1. Log in to Cloudflare → left sidebar → **Workers & Pages**
2. Click **Create** → **Pages** tab → **Upload assets**
3. Project name: `welllivedcitizen` (no spaces, no caps)
4. Drag the `site` folder contents into the upload box (files, not the folder itself)
5. Click **Deploy site**
6. Wait 30 seconds. Click the preview URL Cloudflare gives you. **Your site is live.**
7. Click **Custom domains** tab → **Set up a custom domain** → type `thewelllivedcitizen.com` → Continue → Activate. Parking page dies, real site shows up within minutes.
8. Repeat step 7 with `www.thewelllivedcitizen.com`

## Then: 301 the old domain

In Cloudflare, open `thewelllivedcitizenco.com`. Go to **Rules** → **Redirect Rules** → **Create rule**.

- Name: `301 to new domain`
- Field: Hostname · equals · `thewelllivedcitizenco.com`
- Action: Static redirect · URL: `https://thewelllivedcitizen.com${uri}` · Status: 301 Permanent

Add a second rule for `www.thewelllivedcitizenco.com` the same way.

## Test the contact form

Go to the live site → Contact → fill out the form and submit. Check dayna@thewelllivedcitizen.com within a few minutes. First time Formspree may ask you to confirm the email — check your spam folder if you don't see it.

## To make changes later

Tell me (or any Claude) what you want changed. I give you an updated zip. You go back to Cloudflare Pages → your project → **Create deployment** → drag new folder → Deploy. 30 seconds.

## What's in the zip

- 9 styled pages (home, about, services + 4 subpages, pricing, contact)
- The Manus stylesheet — full elevated design
- Logo + Dayna photo
- info-loader.js (dynamic contact loader, has fallback if offline)
- robots.txt + sitemap.xml for SEO
- Formspree endpoint wired: xreojkvo → dayna@thewelllivedcitizen.com
- GA4 tag G-HN9C986JLW on every page
- Correct social links including pretty URLs (posh.mk/HLUmmsrzq2b, ebay.us/m/cUjlUb)
- Phone (323) 433-1350, SMS (310) 993-0204

## What's NOT in the zip

- The admin dashboard (that was a React app needing a Node server — we can build a simpler admin later that works with this static site)
- The Manus server backend (not needed — `info-loader.js` has hardcoded fallback values)
