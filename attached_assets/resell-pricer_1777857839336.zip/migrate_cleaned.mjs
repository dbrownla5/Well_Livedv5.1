import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(conn);

try {
  await conn.execute('ALTER TABLE `batch_photos` ADD `cleanedUrl` text');
  console.log('Added cleanedUrl to batch_photos');
} catch (e) { console.log('batch_photos cleanedUrl:', e.message); }

try {
  await conn.execute('ALTER TABLE `batch_photos` ADD `cleanedS3Key` varchar(512)');
  console.log('Added cleanedS3Key to batch_photos');
} catch (e) { console.log('batch_photos cleanedS3Key:', e.message); }

try {
  await conn.execute('ALTER TABLE `item_photos` ADD `cleanedUrl` text');
  console.log('Added cleanedUrl to item_photos');
} catch (e) { console.log('item_photos cleanedUrl:', e.message); }

try {
  await conn.execute('ALTER TABLE `item_photos` ADD `cleanedS3Key` varchar(512)');
  console.log('Added cleanedS3Key to item_photos');
} catch (e) { console.log('item_photos cleanedS3Key:', e.message); }

await conn.end();
console.log('Done.');
