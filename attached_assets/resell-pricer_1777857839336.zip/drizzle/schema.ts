import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * A batch represents one upload session (up to 20 photos, ~5 items).
 */
export const batches = mysqlTable("batches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  consigneeClient: varchar("consigneeClient", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["uploading", "processing", "review", "exported", "error"])
    .default("uploading")
    .notNull(),
  sheetsUrl: text("sheetsUrl"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Batch = typeof batches.$inferSelect;
export type InsertBatch = typeof batches.$inferInsert;

/**
 * An item is one identified product from a batch (grouped from 3-4 angle photos).
 */
export const items = mysqlTable("items", {
  id: int("id").autoincrement().primaryKey(),
  batchId: int("batchId").notNull(),
  itemIndex: int("itemIndex").notNull(), // order within batch (0-based)

  // AI-detected attributes
  brand: varchar("brand", { length: 255 }),
  category: varchar("category", { length: 255 }),
  style: varchar("style", { length: 255 }),
  fabric: varchar("fabric", { length: 255 }),
  color: varchar("color", { length: 255 }),
  description: text("description"),
  condition: mysqlEnum("condition", ["New", "Like New", "Good", "Fair"]).default("Good"),
  conditionNotes: text("conditionNotes"),

  // Market data
  priceRangeLow: decimal("priceRangeLow", { precision: 10, scale: 2 }),
  priceRangeHigh: decimal("priceRangeHigh", { precision: 10, scale: 2 }),
  estimatedDaysToSell: int("estimatedDaysToSell"),
  marketSources: json("marketSources"), // array of {platform, price, url, title}

  // Platform recommendation
  recommendedPlatform: varchar("recommendedPlatform", { length: 64 }),

  // Generated listing copy
  listingCopy: json("listingCopy"), // { poshmarkTitle, poshmarkDescription, ebayTitle, ebayDescription, etsyTitle, etsyDescription, facebookTitle, facebookDescription, hashtags, measurements }

  // Manual overrides
  manualCondition: mysqlEnum("manualCondition", ["New", "Like New", "Good", "Fair"]),
  manualPriceLow: decimal("manualPriceLow", { precision: 10, scale: 2 }),
  manualPriceHigh: decimal("manualPriceHigh", { precision: 10, scale: 2 }),
  notes: text("notes"),

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Item = typeof items.$inferSelect;
export type InsertItem = typeof items.$inferInsert;

/**
 * Individual photos belonging to an item.
 */
export const itemPhotos = mysqlTable("item_photos", {
  id: int("id").autoincrement().primaryKey(),
  itemId: int("itemId").notNull(),
  batchId: int("batchId").notNull(),
  s3Key: varchar("s3Key", { length: 512 }).notNull(),
  url: text("url").notNull(),
  cleanedUrl: text("cleanedUrl"), // background-removed version
  cleanedS3Key: varchar("cleanedS3Key", { length: 512 }),
  originalFilename: varchar("originalFilename", { length: 255 }),
  angleLabel: varchar("angleLabel", { length: 64 }), // e.g. "front", "back", "label", "detail"
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ItemPhoto = typeof itemPhotos.$inferSelect;
export type InsertItemPhoto = typeof itemPhotos.$inferInsert;

/**
 * Unassigned photos — uploaded but not yet grouped into items.
 */
export const batchPhotos = mysqlTable("batch_photos", {
  id: int("id").autoincrement().primaryKey(),
  batchId: int("batchId").notNull(),
  s3Key: varchar("s3Key", { length: 512 }).notNull(),
  url: text("url").notNull(),
  cleanedUrl: text("cleanedUrl"), // background-removed version
  cleanedS3Key: varchar("cleanedS3Key", { length: 512 }),
  originalFilename: varchar("originalFilename", { length: 255 }),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BatchPhoto = typeof batchPhotos.$inferSelect;
export type InsertBatchPhoto = typeof batchPhotos.$inferInsert;
