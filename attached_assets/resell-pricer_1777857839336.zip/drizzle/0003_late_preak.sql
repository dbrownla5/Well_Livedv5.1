ALTER TABLE `batch_photos` ADD `cleanedUrl` text;--> statement-breakpoint
ALTER TABLE `batch_photos` ADD `cleanedS3Key` varchar(512);--> statement-breakpoint
ALTER TABLE `item_photos` ADD `cleanedUrl` text;--> statement-breakpoint
ALTER TABLE `item_photos` ADD `cleanedS3Key` varchar(512);