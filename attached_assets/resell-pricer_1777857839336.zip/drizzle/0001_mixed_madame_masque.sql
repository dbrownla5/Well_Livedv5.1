CREATE TABLE `batch_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchId` int NOT NULL,
	`s3Key` varchar(512) NOT NULL,
	`url` text NOT NULL,
	`originalFilename` varchar(255),
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `batch_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `batches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`consigneeClient` varchar(255) NOT NULL,
	`status` enum('uploading','processing','review','exported','error') NOT NULL DEFAULT 'uploading',
	`sheetsUrl` text,
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `batches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `item_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemId` int NOT NULL,
	`batchId` int NOT NULL,
	`s3Key` varchar(512) NOT NULL,
	`url` text NOT NULL,
	`originalFilename` varchar(255),
	`angleLabel` varchar(64),
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `item_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchId` int NOT NULL,
	`itemIndex` int NOT NULL,
	`brand` varchar(255),
	`category` varchar(255),
	`style` varchar(255),
	`fabric` varchar(255),
	`color` varchar(255),
	`description` text,
	`condition` enum('New','Like New','Good','Fair') DEFAULT 'Good',
	`conditionNotes` text,
	`priceRangeLow` decimal(10,2),
	`priceRangeHigh` decimal(10,2),
	`estimatedDaysToSell` int,
	`marketSources` json,
	`manualCondition` enum('New','Like New','Good','Fair'),
	`manualPriceLow` decimal(10,2),
	`manualPriceHigh` decimal(10,2),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `items_id` PRIMARY KEY(`id`)
);
