ALTER TABLE `items` ADD `recommendedPlatform` varchar(64);--> statement-breakpoint
ALTER TABLE `items` ADD `listingCopy` json;