// This file is intentionally minimal — the root route "/" renders UploadPage via App.tsx routing.
export default function Home() {
  return null;
}
