import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  Loader2, ExternalLink, RefreshCw, FileSpreadsheet, ChevronLeft,
  Tag, Shirt, Palette, Layers, TrendingUp, Clock, DollarSign,
  Copy, Wand2, Store, Sparkles, ImageOff, Image
} from "lucide-react";

type Condition = "New" | "Like New" | "Good" | "Fair";

interface MarketSource {
  platform: string;
  title: string;
  price: number;
  condition: string;
  url: string;
}

interface ListingCopy {
  poshmarkTitle: string;
  poshmarkDescription: string;
  ebayTitle: string;
  ebayDescription: string;
  etsyTitle: string;
  etsyDescription: string;
  facebookTitle: string;
  facebookDescription: string;
  hashtags: string[];
  measurements: string;
}

function conditionColor(condition: string) {
  switch (condition) {
    case "New": return "bg-green-100 text-green-800 border-green-200";
    case "Like New": return "bg-blue-100 text-blue-800 border-blue-200";
    case "Good": return "bg-yellow-100 text-yellow-800 border-yellow-200";
    case "Fair": return "bg-orange-100 text-orange-800 border-orange-200";
    default: return "bg-gray-100 text-gray-800 border-gray-200";
  }
}

function platformColor(platform: string) {
  switch (platform.toLowerCase()) {
    case "poshmark": return "bg-red-50 text-red-700 border-red-200";
    case "etsy": return "bg-orange-50 text-orange-700 border-orange-200";
    case "ebay": return "bg-yellow-50 text-yellow-700 border-yellow-200";
    case "facebook marketplace":
    case "facebook": return "bg-blue-50 text-blue-700 border-blue-200";
    default: return "bg-gray-50 text-gray-700 border-gray-200";
  }
}

function platformBadge(platform: string) {
  switch (platform?.toLowerCase()) {
    case "poshmark": return "bg-red-100 text-red-800 border-red-300";
    case "etsy": return "bg-orange-100 text-orange-800 border-orange-300";
    case "ebay": return "bg-yellow-100 text-yellow-800 border-yellow-300";
    case "facebook marketplace":
    case "facebook": return "bg-blue-100 text-blue-800 border-blue-300";
    default: return "bg-gray-100 text-gray-800 border-gray-300";
  }
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className="ml-auto text-muted-foreground hover:text-foreground transition-colors"
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }}
      title="Copy to clipboard"
    >
      <Copy className={`h-3.5 w-3.5 ${copied ? "text-green-600" : ""}`} />
    </button>
  );
}

export default function BatchReviewPage() {
  const params = useParams<{ id: string }>();
  const batchId = parseInt(params.id ?? "0");
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: batch, isLoading, error } = trpc.batch.get.useQuery({ batchId });
  const fetchPricing = trpc.item.fetchBatchPricing.useMutation({
    onSuccess: () => {
      utils.batch.get.invalidate({ batchId });
      toast.success("Market pricing updated for all items.");
    },
    onError: (err) => toast.error(err.message),
  });
  const bgremoveStatus = trpc.bgremove.status.useQuery({ batchId }, { enabled: !!batchId });
  const processBgRemove = trpc.bgremove.processBatch.useMutation({
    onSuccess: (data) => {
      utils.batch.get.invalidate({ batchId });
      bgremoveStatus.refetch();
      toast.success(`Background removed from ${data.successCount} of ${data.totalPhotos} photos.`);
    },
    onError: (err) => toast.error(err.message),
  });

  const generateListings = trpc.item.generateBatchListings.useMutation({
    onSuccess: (data) => {
      utils.batch.get.invalidate({ batchId });
      toast.success(`Listings generated for ${data.successCount} items.`);
    },
    onError: (err) => toast.error(err.message),
  });
  const exportToSheets = trpc.export.toSheets.useMutation({
    onSuccess: (data) => {
      utils.batch.get.invalidate({ batchId });
      toast.success(
        <div className="flex flex-col gap-1">
          <span className="font-medium">Exported to Google Sheets!</span>
          <a href={data.sheetsUrl} target="_blank" rel="noopener noreferrer" className="text-xs underline">
            Open spreadsheet
          </a>
        </div>
      );
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error || !batch) {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center">
        <p className="text-muted-foreground">Batch not found or still processing.</p>
        <Button variant="outline" className="mt-4" onClick={() => setLocation("/")}>
          <ChevronLeft className="mr-2 h-4 w-4" /> Back to Upload
        </Button>
      </div>
    );
  }

  const hasPricing = batch.items?.some((item: any) => item.priceRangeLow);
  const hasListings = batch.items?.some((item: any) => item.listingCopy);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-2 transition-colors"
          >
            <ChevronLeft className="h-4 w-4" /> New Batch
          </button>
          <h1 className="text-2xl font-bold tracking-tight">Batch Review</h1>
          <p className="text-muted-foreground mt-1">
            Client: <span className="font-medium text-foreground">{batch.consigneeClient}</span>
            {" · "}
            {batch.items?.length ?? 0} items identified
            {" · "}
            <span className="capitalize">{batch.status}</span>
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            onClick={() => processBgRemove.mutate({ batchId })}
            disabled={processBgRemove.isPending || fetchPricing.isPending}
            title="Remove backgrounds from all photos automatically"
          >
            {processBgRemove.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="mr-2 h-4 w-4" />
            )}
            {bgremoveStatus.data?.isComplete ? "Re-clean Photos" : "Remove Backgrounds"}
          </Button>
          <Button
            variant="outline"
            onClick={() => fetchPricing.mutate({ batchId })}
            disabled={fetchPricing.isPending || generateListings.isPending}
          >
            {fetchPricing.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="mr-2 h-4 w-4" />
            )}
            {hasPricing ? "Refresh Pricing" : "Fetch Market Pricing"}
          </Button>
          <Button
            variant="outline"
            onClick={() => generateListings.mutate({ batchId })}
            disabled={generateListings.isPending || fetchPricing.isPending || !hasPricing}
            title={!hasPricing ? "Fetch market pricing first" : ""}
          >
            {generateListings.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Wand2 className="mr-2 h-4 w-4" />
            )}
            {hasListings ? "Regenerate Listings" : "Generate Listings"}
          </Button>
          <Button
            onClick={() => exportToSheets.mutate({ batchId })}
            disabled={exportToSheets.isPending || !hasPricing}
          >
            {exportToSheets.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <FileSpreadsheet className="mr-2 h-4 w-4" />
            )}
            Export to Sheets
          </Button>
        </div>
      </div>

      {/* Status banners */}
      {batch.sheetsUrl && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="py-3 flex items-center justify-between">
            <span className="text-sm text-green-800 font-medium">Exported to Google Sheets</span>
            <a
              href={batch.sheetsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-sm text-green-700 underline hover:text-green-900"
            >
              Open Spreadsheet <ExternalLink className="h-3 w-3" />
            </a>
          </CardContent>
        </Card>
      )}

      {processBgRemove.isPending && (
        <Card className="border-indigo-200 bg-indigo-50">
          <CardContent className="py-4 flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-indigo-600" />
            <div>
              <p className="text-sm font-medium text-indigo-900">Removing backgrounds...</p>
              <p className="text-xs text-indigo-700">AI is cleaning each photo. This takes 10–30 seconds per photo.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {bgremoveStatus.data && bgremoveStatus.data.cleaned > 0 && !processBgRemove.isPending && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="py-3 flex items-center justify-between">
            <span className="text-sm text-green-800 font-medium">
              <Sparkles className="h-4 w-4 inline mr-1.5 text-green-600" />
              {bgremoveStatus.data.cleaned} of {bgremoveStatus.data.total} photos cleaned
            </span>
            {!bgremoveStatus.data.isComplete && (
              <span className="text-xs text-green-700">{bgremoveStatus.data.pending} remaining</span>
            )}
          </CardContent>
        </Card>
      )}

      {fetchPricing.isPending && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="py-4 flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <div>
              <p className="text-sm font-medium">Fetching market pricing...</p>
              <p className="text-xs text-muted-foreground">Searching Poshmark, Etsy, eBay, and Facebook Marketplace for comparable sold listings.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {generateListings.isPending && (
        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="py-4 flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-purple-600" />
            <div>
              <p className="text-sm font-medium text-purple-900">Generating listing copy...</p>
              <p className="text-xs text-purple-700">Writing Poshmark, eBay, Etsy, and Facebook listings for all items.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Item Cards */}
      <div className="space-y-6">
        {(batch.items ?? []).map((item: any, index: number) => (
          <ItemCard key={item.id} item={item} index={index} batchId={batchId} />
        ))}
      </div>

      {/* Bottom Export */}
      {(batch.items?.length ?? 0) > 0 && (
        <div className="flex justify-end pt-2 pb-8">
          <Button
            size="lg"
            onClick={() => exportToSheets.mutate({ batchId })}
            disabled={exportToSheets.isPending || !hasPricing}
          >
            {exportToSheets.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <FileSpreadsheet className="mr-2 h-4 w-4" />
            )}
            Export to Google Sheets
          </Button>
        </div>
      )}
    </div>
  );
}

// ─── Item Card ────────────────────────────────────────────────────────────────

function ItemCard({ item, index, batchId }: { item: any; index: number; batchId: number }) {
  const utils = trpc.useUtils();
  const [editing, setEditing] = useState(false);
  const [showCleaned, setShowCleaned] = useState(true);
  const hasCleaned = (item.photos ?? []).some((p: any) => p.cleanedUrl);
  const [form, setForm] = useState({
    brand: item.brand ?? "",
    category: item.category ?? "",
    style: item.style ?? "",
    fabric: item.fabric ?? "",
    color: item.color ?? "",
    description: item.description ?? "",
    manualCondition: (item.manualCondition ?? item.condition ?? "Good") as Condition,
    manualPriceLow: item.manualPriceLow ?? item.priceRangeLow ?? "",
    manualPriceHigh: item.manualPriceHigh ?? item.priceRangeHigh ?? "",
    notes: item.notes ?? "",
  });

  const updateItem = trpc.item.update.useMutation({
    onSuccess: () => {
      utils.batch.get.invalidate({ batchId });
      setEditing(false);
      toast.success("Item updated.");
    },
    onError: (err) => toast.error(err.message),
  });

  const fetchItemPricing = trpc.item.fetchPricing.useMutation({
    onSuccess: () => {
      utils.batch.get.invalidate({ batchId });
      toast.success("Pricing updated.");
    },
    onError: (err) => toast.error(err.message),
  });

  const generateItemListing = trpc.item.generateListings.useMutation({
    onSuccess: () => {
      utils.batch.get.invalidate({ batchId });
      toast.success("Listing copy generated.");
    },
    onError: (err) => toast.error(err.message),
  });

  const effectiveCondition = item.manualCondition ?? item.condition ?? "Good";
  const effectivePriceLow = item.manualPriceLow ?? item.priceRangeLow;
  const effectivePriceHigh = item.manualPriceHigh ?? item.priceRangeHigh;
  const marketSources = (item.marketSources as MarketSource[] | null) ?? [];
  const listingCopy = item.listingCopy as ListingCopy | null;
  const recommendedPlatform = item.recommendedPlatform as string | null;

  const handleSave = () => {
    updateItem.mutate({
      itemId: item.id,
      brand: form.brand,
      category: form.category,
      style: form.style,
      fabric: form.fabric,
      color: form.color,
      description: form.description,
      manualCondition: form.manualCondition,
      manualPriceLow: form.manualPriceLow ? parseFloat(form.manualPriceLow) : undefined,
      manualPriceHigh: form.manualPriceHigh ? parseFloat(form.manualPriceHigh) : undefined,
      notes: form.notes,
    });
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3 bg-muted/20">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <span className="h-6 w-6 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center font-bold shrink-0">
              {index + 1}
            </span>
            {item.brand && item.brand !== "Unknown" ? item.brand : "Unknown Brand"}{" "}
            {item.style && <span className="text-muted-foreground font-normal">— {item.style}</span>}
            {recommendedPlatform && (
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium flex items-center gap-1 ${platformBadge(recommendedPlatform)}`}>
                <Store className="h-3 w-3" />
                {recommendedPlatform}
              </span>
            )}
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${conditionColor(effectiveCondition)}`}>
              {effectiveCondition}
            </span>
            {!editing ? (
              <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit</Button>
            ) : (
              <div className="flex gap-1.5">
                <Button variant="outline" size="sm" onClick={() => setEditing(false)}>Cancel</Button>
                <Button size="sm" onClick={handleSave} disabled={updateItem.isPending}>
                  {updateItem.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Save"}
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-4 space-y-5">
        <Tabs defaultValue="details">
          <TabsList className="h-8 text-xs">
            <TabsTrigger value="details" className="text-xs px-3">Details</TabsTrigger>
            <TabsTrigger value="pricing" className="text-xs px-3">Pricing</TabsTrigger>
            <TabsTrigger value="listings" className="text-xs px-3">
              Listings
              {listingCopy && <span className="ml-1 h-1.5 w-1.5 rounded-full bg-green-500 inline-block" />}
            </TabsTrigger>
          </TabsList>

          {/* ── Details Tab ── */}
          <TabsContent value="details" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Photos */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Photos</p>
                  {hasCleaned && (
                    <button
                      onClick={() => setShowCleaned((v) => !v)}
                      className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors border rounded px-1.5 py-0.5"
                      title={showCleaned ? "Show original photos" : "Show cleaned photos"}
                    >
                      {showCleaned ? <Image className="h-3 w-3" /> : <Sparkles className="h-3 w-3" />}
                      {showCleaned ? "Original" : "Cleaned"}
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(item.photos ?? []).slice(0, 6).map((photo: any) => {
                    const displayUrl = (showCleaned && photo.cleanedUrl) ? photo.cleanedUrl : photo.url;
                    return (
                      <div key={photo.id} className="relative aspect-square">
                        <img
                          src={displayUrl}
                          alt={photo.angleLabel ?? "photo"}
                          className="w-full h-full object-cover rounded-md border"
                        />
                        {photo.cleanedUrl && showCleaned && (
                          <span className="absolute top-0.5 right-0.5 bg-indigo-500 text-white text-[8px] rounded px-1 py-0.5 leading-none">
                            ✓
                          </span>
                        )}
                        {photo.angleLabel && (
                          <span className="absolute bottom-0.5 left-0.5 right-0.5 text-center text-[9px] bg-black/60 text-white rounded px-1 truncate">
                            {photo.angleLabel}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Attributes */}
              <div className="space-y-3">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Attributes</p>
                {editing ? (
                  <div className="space-y-2.5">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs">Brand</Label>
                        <Input value={form.brand} onChange={(e) => setForm((f) => ({ ...f, brand: e.target.value }))} className="h-8 text-sm mt-1" />
                      </div>
                      <div>
                        <Label className="text-xs">Category</Label>
                        <Input value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} className="h-8 text-sm mt-1" />
                      </div>
                      <div>
                        <Label className="text-xs">Style</Label>
                        <Input value={form.style} onChange={(e) => setForm((f) => ({ ...f, style: e.target.value }))} className="h-8 text-sm mt-1" />
                      </div>
                      <div>
                        <Label className="text-xs">Color</Label>
                        <Input value={form.color} onChange={(e) => setForm((f) => ({ ...f, color: e.target.value }))} className="h-8 text-sm mt-1" />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Fabric</Label>
                      <Input value={form.fabric} onChange={(e) => setForm((f) => ({ ...f, fabric: e.target.value }))} className="h-8 text-sm mt-1" />
                    </div>
                    <div>
                      <Label className="text-xs">Condition</Label>
                      <Select value={form.manualCondition} onValueChange={(v) => setForm((f) => ({ ...f, manualCondition: v as Condition }))}>
                        <SelectTrigger className="h-8 text-sm mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(["New", "Like New", "Good", "Fair"] as Condition[]).map((c) => (
                            <SelectItem key={c} value={c}>{c}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Description</Label>
                      <Textarea value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className="text-sm mt-1 min-h-[60px]" />
                    </div>
                    <div>
                      <Label className="text-xs">Notes</Label>
                      <Textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} className="text-sm mt-1 min-h-[48px]" placeholder="Internal notes..." />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {[
                      { icon: Tag, label: "Brand", value: item.brand },
                      { icon: Shirt, label: "Category / Style", value: [item.category, item.style].filter(Boolean).join(" · ") },
                      { icon: Layers, label: "Fabric", value: item.fabric },
                      { icon: Palette, label: "Color", value: item.color },
                    ].map(({ icon: Icon, label, value }) => (
                      <div key={label} className="flex items-start gap-2 text-sm">
                        <Icon className="h-3.5 w-3.5 text-muted-foreground mt-0.5 shrink-0" />
                        <span className="text-muted-foreground w-24 shrink-0">{label}</span>
                        <span className="font-medium">{value || <span className="text-muted-foreground italic">—</span>}</span>
                      </div>
                    ))}
                    {item.description && (
                      <p className="text-xs text-muted-foreground mt-2 leading-relaxed border-t pt-2">{item.description}</p>
                    )}
                    {item.conditionNotes && (
                      <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1">{item.conditionNotes}</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* ── Pricing Tab ── */}
          <TabsContent value="pricing" className="mt-4 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Market Pricing</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => fetchItemPricing.mutate({ itemId: item.id })}
                disabled={fetchItemPricing.isPending}
              >
                {fetchItemPricing.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <RefreshCw className="h-3 w-3 mr-1" />}
                Refresh
              </Button>
            </div>

            {effectivePriceLow ? (
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-muted/40 rounded-lg p-3 text-center">
                  <DollarSign className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">Price Range</p>
                  <p className="font-bold text-sm mt-0.5">
                    ${parseFloat(effectivePriceLow).toFixed(0)} – ${parseFloat(effectivePriceHigh).toFixed(0)}
                  </p>
                </div>
                <div className="bg-muted/40 rounded-lg p-3 text-center">
                  <Clock className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">Est. Days to Sell</p>
                  <p className="font-bold text-sm mt-0.5">
                    {item.estimatedDaysToSell ? `${item.estimatedDaysToSell}d` : "—"}
                  </p>
                </div>
                <div className="bg-muted/40 rounded-lg p-3 text-center">
                  <TrendingUp className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">Comps Found</p>
                  <p className="font-bold text-sm mt-0.5">{marketSources.length}</p>
                </div>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground bg-muted/30 rounded-lg p-3">
                No pricing data yet. Click "Fetch Market Pricing" above.
              </div>
            )}

            {editing && (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Override Price Low ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={form.manualPriceLow}
                    onChange={(e) => setForm((f) => ({ ...f, manualPriceLow: e.target.value }))}
                    className="h-8 text-sm mt-1"
                    placeholder={item.priceRangeLow ?? "0.00"}
                  />
                </div>
                <div>
                  <Label className="text-xs">Override Price High ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={form.manualPriceHigh}
                    onChange={(e) => setForm((f) => ({ ...f, manualPriceHigh: e.target.value }))}
                    className="h-8 text-sm mt-1"
                    placeholder={item.priceRangeHigh ?? "0.00"}
                  />
                </div>
              </div>
            )}

            {marketSources.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">Comparable sold listings:</p>
                <div className="space-y-1.5">
                  {marketSources.slice(0, 6).map((source, i) => (
                    <div key={i} className="flex items-center justify-between gap-2 text-xs bg-muted/20 rounded px-2.5 py-1.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium border shrink-0 ${platformColor(source.platform)}`}>
                          {source.platform}
                        </span>
                        <span className="truncate text-muted-foreground">{source.title}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-semibold">${source.price.toFixed(0)}</span>
                        {source.url && source.url.startsWith("http") && (
                          <a href={source.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* ── Listings Tab ── */}
          <TabsContent value="listings" className="mt-4 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Listing Copy</p>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs"
                onClick={() => generateItemListing.mutate({ itemId: item.id })}
                disabled={generateItemListing.isPending}
              >
                {generateItemListing.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Wand2 className="h-3 w-3 mr-1" />}
                {listingCopy ? "Regenerate" : "Generate"}
              </Button>
            </div>

            {generateItemListing.isPending && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/30 rounded-lg p-3">
                <Loader2 className="h-4 w-4 animate-spin" />
                Writing listing copy for all platforms...
              </div>
            )}

            {listingCopy ? (
              <div className="space-y-4">
                {/* Measurements */}
                {listingCopy.measurements && (
                  <div className="bg-muted/30 rounded-lg p-3">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Estimated Measurements</p>
                    <p className="text-sm font-medium">{listingCopy.measurements}</p>
                  </div>
                )}

                {/* Platform listings */}
                {[
                  { key: "poshmark", label: "Poshmark", title: listingCopy.poshmarkTitle, desc: listingCopy.poshmarkDescription },
                  { key: "ebay", label: "eBay", title: listingCopy.ebayTitle, desc: listingCopy.ebayDescription },
                  { key: "etsy", label: "Etsy", title: listingCopy.etsyTitle, desc: listingCopy.etsyDescription },
                  { key: "facebook", label: "Facebook", title: listingCopy.facebookTitle, desc: listingCopy.facebookDescription },
                ].map(({ key, label, title, desc }) => (
                  <div key={key} className="border rounded-lg overflow-hidden">
                    <div className={`px-3 py-2 flex items-center justify-between ${platformColor(key === "facebook" ? "facebook marketplace" : key)}`}>
                      <span className="text-xs font-semibold">{label}</span>
                    </div>
                    <div className="p-3 space-y-2.5">
                      <div>
                        <div className="flex items-center gap-1 mb-1">
                          <p className="text-xs text-muted-foreground font-medium">Title</p>
                          <CopyButton text={title} />
                        </div>
                        <p className="text-sm font-medium leading-snug">{title}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{title.length} chars</p>
                      </div>
                      <Separator />
                      <div>
                        <div className="flex items-center gap-1 mb-1">
                          <p className="text-xs text-muted-foreground font-medium">Description</p>
                          <CopyButton text={desc} />
                        </div>
                        <p className="text-xs leading-relaxed text-foreground whitespace-pre-wrap">{desc}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Hashtags */}
                {listingCopy.hashtags?.length > 0 && (
                  <div>
                    <div className="flex items-center gap-1 mb-2">
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Poshmark Hashtags</p>
                      <CopyButton text={listingCopy.hashtags.map(h => `#${h}`).join(" ")} />
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {listingCopy.hashtags.map((tag, i) => (
                        <span key={i} className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground bg-muted/30 rounded-lg p-4 text-center">
                <Wand2 className="h-6 w-6 mx-auto mb-2 text-muted-foreground/50" />
                <p>No listing copy yet.</p>
                <p className="text-xs mt-1">Fetch market pricing first, then click "Generate Listings" to write copy for all platforms.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
