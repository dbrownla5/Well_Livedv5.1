import { useState, useCallback, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Upload, X, ImageIcon, Loader2, AlertCircle, CheckCircle2 } from "lucide-react";

interface PhotoFile {
  file: File;
  preview: string;
  id: string;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip the data URL prefix (e.g. "data:image/jpeg;base64,")
      resolve(result.split(",")[1] ?? "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function UploadPage() {
  const [, setLocation] = useLocation();
  const [photos, setPhotos] = useState<PhotoFile[]>([]);
  const [clientName, setClientName] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStep, setUploadStep] = useState<"idle" | "uploading" | "processing" | "done">("idle");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createBatch = trpc.batch.create.useMutation();
  const processBatch = trpc.batch.process.useMutation();

  const addPhotos = useCallback((files: File[]) => {
    const imageFiles = files.filter((f) => f.type.startsWith("image/"));
    const remaining = 20 - photos.length;
    const toAdd = imageFiles.slice(0, remaining);

    if (toAdd.length < imageFiles.length) {
      toast.warning(`Maximum 20 photos per batch. Added ${toAdd.length} of ${imageFiles.length}.`);
    }

    const newPhotos: PhotoFile[] = toAdd.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
      id: `${Date.now()}-${Math.random()}`,
    }));

    setPhotos((prev) => [...prev, ...newPhotos]);
  }, [photos.length]);

  const removePhoto = (id: string) => {
    setPhotos((prev) => {
      const photo = prev.find((p) => p.id === id);
      if (photo) URL.revokeObjectURL(photo.preview);
      return prev.filter((p) => p.id !== id);
    });
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      addPhotos(Array.from(e.dataTransfer.files));
    },
    [addPhotos]
  );

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) addPhotos(Array.from(e.target.files));
    e.target.value = "";
  };

  const handleSubmit = async () => {
    if (!clientName.trim()) {
      toast.error("Please enter a consignee client name.");
      return;
    }
    if (photos.length < 3) {
      toast.error("Please upload at least 3 photos.");
      return;
    }

    try {
      setUploadStep("uploading");

      // Convert photos to base64
      const photoData = await Promise.all(
        photos.map(async (p) => ({
          filename: p.file.name,
          mimeType: p.file.type,
          base64: await fileToBase64(p.file),
        }))
      );

      // Create batch and upload to S3
      const { batchId } = await createBatch.mutateAsync({
        consigneeClient: clientName.trim(),
        photos: photoData,
      });

      setUploadStep("processing");

      // Run AI processing
      await processBatch.mutateAsync({ batchId });

      setUploadStep("done");
      toast.success("Batch processed! Redirecting to review...");

      setTimeout(() => {
        setLocation(`/batch/${batchId}`);
      }, 1000);
    } catch (err) {
      setUploadStep("idle");
      const msg = err instanceof Error ? err.message : "Upload failed";
      toast.error(msg);
    }
  };

  const isProcessing = uploadStep === "uploading" || uploadStep === "processing";

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">New Batch</h1>
        <p className="text-muted-foreground mt-1">
          Upload 15–20 photos of 3–5 items. The AI will group angles, identify each item, and generate market pricing.
        </p>
      </div>

      {/* Client Name */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Consignee Client</CardTitle>
          <CardDescription>Enter the client name for this batch of items.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="max-w-sm">
            <Label htmlFor="client-name">Client Name</Label>
            <Input
              id="client-name"
              placeholder="e.g. Jane Smith"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              disabled={isProcessing}
              className="mt-1.5"
            />
          </div>
        </CardContent>
      </Card>

      {/* Photo Upload */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">Photos</CardTitle>
              <CardDescription>
                Upload 3–4 angles per item. Mix all items together — the AI will group them automatically.
              </CardDescription>
            </div>
            <Badge variant={photos.length >= 20 ? "destructive" : "secondary"}>
              {photos.length} / 20
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Drop Zone */}
          <div
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
              isDragging
                ? "border-primary bg-primary/5"
                : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/30"
            } ${photos.length >= 20 ? "opacity-50 pointer-events-none" : ""}`}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileInput}
            />
            <div className="flex flex-col items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                <Upload className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium text-sm">Drop photos here or click to browse</p>
                <p className="text-xs text-muted-foreground mt-1">
                  JPG, PNG, HEIC — up to 20 photos per batch
                </p>
              </div>
            </div>
          </div>

          {/* Photo Grid */}
          {photos.length > 0 && (
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2">
              {photos.map((photo) => (
                <div key={photo.id} className="relative group aspect-square">
                  <img
                    src={photo.preview}
                    alt={photo.file.name}
                    className="w-full h-full object-cover rounded-lg border"
                  />
                  <button
                    onClick={(e) => { e.stopPropagation(); removePhoto(photo.id); }}
                    disabled={isProcessing}
                    className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {photos.length === 0 && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/30 rounded-lg p-3">
              <ImageIcon className="h-4 w-4 shrink-0" />
              <span>No photos added yet. Upload 3–4 angles per item for best results.</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Processing Status */}
      {isProcessing && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <p className="font-medium text-sm">
                  {uploadStep === "uploading" ? "Uploading photos..." : "AI is analyzing your items..."}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {uploadStep === "uploading"
                    ? "Securely uploading your photos to storage."
                    : "Grouping angles, identifying brands, fabrics, and styles. This takes 30–60 seconds."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {uploadStep === "done" && (
        <Card className="border-green-500/30 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <p className="font-medium text-sm text-green-800">Processing complete! Redirecting to review...</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tips */}
      <Card className="bg-muted/30 border-muted">
        <CardContent className="pt-4 pb-4">
          <div className="flex gap-2">
            <AlertCircle className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
            <div className="text-xs text-muted-foreground space-y-1">
              <p><strong>For best results:</strong> Include a photo of the tag/label for brand and fabric detection. Mix all item angles together — the AI handles grouping automatically.</p>
              <p>Pricing is pulled from comparable sold listings on Poshmark, Etsy, eBay, and The RealReal. All fields are editable before export.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Submit */}
      <div className="flex justify-end">
        <Button
          size="lg"
          onClick={handleSubmit}
          disabled={isProcessing || photos.length < 3 || !clientName.trim()}
          className="min-w-[160px]"
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {uploadStep === "uploading" ? "Uploading..." : "Processing..."}
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Process Batch
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
