import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Loader2, ExternalLink, Trash2, Eye, FileSpreadsheet,
  Clock, CheckCircle2, AlertCircle, Upload, RefreshCw, Play
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

function statusBadge(status: string) {
  switch (status) {
    case "exported":
      return <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-100"><CheckCircle2 className="h-3 w-3 mr-1" />Exported</Badge>;
    case "review":
      return <Badge className="bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-100"><Eye className="h-3 w-3 mr-1" />Ready to Review</Badge>;
    case "processing":
      return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 hover:bg-yellow-100"><Loader2 className="h-3 w-3 mr-1 animate-spin" />Processing</Badge>;
    case "uploading":
      return <Badge className="bg-gray-100 text-gray-700 border-gray-200 hover:bg-gray-100"><Upload className="h-3 w-3 mr-1" />Uploading</Badge>;
    case "error":
      return <Badge className="bg-red-100 text-red-800 border-red-200 hover:bg-red-100"><AlertCircle className="h-3 w-3 mr-1" />Error</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function HistoryPage() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: batches, isLoading } = trpc.batch.list.useQuery();
  const deleteBatch = trpc.batch.delete.useMutation({
    onSuccess: () => {
      utils.batch.list.invalidate();
      toast.success("Batch deleted.");
    },
    onError: (err) => toast.error(err.message),
  });
  const retryProcess = trpc.batch.process.useMutation({
    onSuccess: (data) => {
      utils.batch.list.invalidate();
      toast.success(`Processing complete — ${data.itemCount} items identified.`);
    },
    onError: (err) => {
      utils.batch.list.invalidate();
      toast.error(`Processing failed: ${err.message}`);
    },
  });

  const exportToSheets = trpc.export.toSheets.useMutation({
    onSuccess: (data) => {
      utils.batch.list.invalidate();
      toast.success(
        <div className="flex flex-col gap-1">
          <span className="font-medium">Exported to Google Sheets!</span>
          <a href={data.sheetsUrl} target="_blank" rel="noopener noreferrer" className="text-xs underline">
            Open spreadsheet
          </a>
        </div>
      );
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Batch History</h1>
          <p className="text-muted-foreground mt-1">
            {batches?.length ?? 0} batch{batches?.length !== 1 ? "es" : ""} processed
          </p>
        </div>
        <Button onClick={() => setLocation("/")}>
          <Upload className="mr-2 h-4 w-4" />
          New Batch
        </Button>
      </div>

      {(!batches || batches.length === 0) && (
        <Card className="border-dashed">
          <CardContent className="py-16 text-center">
            <FileSpreadsheet className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
            <p className="font-medium">No batches yet</p>
            <p className="text-sm text-muted-foreground mt-1">Upload your first batch of photos to get started.</p>
            <Button className="mt-4" onClick={() => setLocation("/")}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Photos
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {(batches ?? []).map((batch) => (
          <Card key={batch.id} className="hover:shadow-sm transition-shadow">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-start gap-3 min-w-0">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="h-5 w-5 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold truncate">{batch.consigneeClient}</span>
                      {statusBadge(batch.status)}
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(batch.createdAt).toLocaleDateString("en-US", {
                          month: "short", day: "numeric", year: "numeric",
                          hour: "numeric", minute: "2-digit"
                        })}
                      </span>
                      <span>Batch #{batch.id}</span>
                    </div>
                    {batch.errorMessage && (
                      <p className="text-xs text-destructive mt-1">{batch.errorMessage}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap shrink-0">
                  {batch.sheetsUrl && (
                    <a href={batch.sheetsUrl} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm">
                        <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
                        View Sheet
                      </Button>
                    </a>
                  )}

                  {(batch.status === "processing" || batch.status === "error" || batch.status === "uploading") && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => retryProcess.mutate({ batchId: batch.id })}
                      disabled={retryProcess.isPending}
                      title="Retry AI processing for this batch"
                    >
                      {retryProcess.isPending ? (
                        <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Play className="mr-1.5 h-3.5 w-3.5" />
                      )}
                      Retry Processing
                    </Button>
                  )}

                  {(batch.status === "review" || batch.status === "exported") && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setLocation(`/batch/${batch.id}`)}
                      >
                        <Eye className="mr-1.5 h-3.5 w-3.5" />
                        Review
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportToSheets.mutate({ batchId: batch.id })}
                        disabled={exportToSheets.isPending}
                      >
                        {exportToSheets.isPending ? (
                          <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                        )}
                        Re-export
                      </Button>
                    </>
                  )}

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this batch?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete the batch for <strong>{batch.consigneeClient}</strong> and all associated items and photos. This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => deleteBatch.mutate({ batchId: batch.id })}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
