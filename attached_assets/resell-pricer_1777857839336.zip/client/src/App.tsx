import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import UploadPage from "./pages/UploadPage";
import BatchReviewPage from "./pages/BatchReviewPage";
import HistoryPage from "./pages/HistoryPage";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={UploadPage} />
        <Route path="/batch/:id" component={BatchReviewPage} />
        <Route path="/history" component={HistoryPage} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
