# Resell Pricer - TODO

## Database & Backend
- [x] Define schema: batches, items, item_photos tables
- [x] Run migration SQL via webdev_execute_sql
- [x] S3 photo upload endpoint (multipart, up to 20 photos)
- [x] AI item grouping procedure (vision AI groups 3-4 angles → 1 item)
- [x] AI attribute detection: brand, fabric, style, category, color, condition
- [x] Market valuation router: Poshmark, Etsy, eBay, The RealReal comps
- [x] Price range + estimated time-to-sell calculation
- [x] Batch CRUD: create, list, update item fields, delete
- [x] Google Sheets export procedure

## Frontend
- [x] App layout with DashboardLayout sidebar
- [x] Upload page: drag-and-drop, 20-photo batch, client name entry
- [x] Processing page: progress indicator while AI runs
- [x] Batch review page: grouped photos, editable attributes, price range, condition override
- [x] History page: list of past batches, re-export, edit
- [x] Google Sheets export button with status feedback
- [x] Responsive design, clean inventory management aesthetic

## Testing
- [x] Vitest: upload procedure
- [x] Vitest: item grouping logic
- [x] Vitest: batch CRUD operations
- [x] Vitest: export procedure

## Phase 2 — Listing Generator + Platform Updates
- [x] Remove The RealReal from all pricing sources
- [x] Add Facebook Marketplace as a pricing/platform source
- [x] Update item router: pricing pulls from Poshmark, eBay, Etsy, Facebook only
- [x] Add listing generator router: generates Poshmark, eBay, Etsy, Facebook title+description per item
- [x] Add platform recommendation logic (which platform is best for this item category)
- [ ] Add background removal endpoint (AI removes background from uploaded photos) [deferred - next session]
- [x] Frontend: Listing Generator tab on batch review page
- [ ] Frontend: Background removal in upload flow [deferred - next session]
- [x] Frontend: Platform recommendation badge on each item card
- [x] Update Sheets export: add platform recommendation column and listing copy columns

## Phase 3 — Background Removal
- [x] Backend: background removal procedure using AI image editing (remove background, return clean S3 URL)
- [x] Backend: store both original URL and cleaned URL per photo in item_photos table
- [x] Frontend: batch review shows Remove Backgrounds button with progress banner
- [x] Frontend: batch review shows cleaned photos by default with toggle to see original
- [ ] Frontend: download cleaned photos as zip per item [future]
- [x] Test background removal with Halston bag photos (confirmed via AI test script)

## Bug Fixes — Batch Loss + BG Removal Speed
- [x] Diagnose why 2 of 3 batch runs disappeared from history — stuck in 'processing' state due to AI timeout
- [x] Fix: batches persist on error — status flips to 'error' with message, never lost
- [x] Fix: background removal now runs 3 photos in parallel (was sequential)
- [x] Add per-photo timeout: 45s cap per photo, batch continues if one fails
- [x] Add Retry Processing button on History page for stuck/error batches
