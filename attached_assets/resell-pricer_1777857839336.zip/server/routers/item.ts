import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getItemById, getItemsByBatch, updateItem, getBatchById } from "../db";
import { invokeLLM } from "../_core/llm";

// ─── Types ────────────────────────────────────────────────────────────────────

interface MarketSource {
  platform: string;
  title: string;
  price: number;
  condition: string;
  url: string;
}

interface MarketData {
  sources: MarketSource[];
  priceLow: number;
  priceHigh: number;
  estimatedDaysToSell: number;
  pricingRationale: string;
  recommendedPlatform: string;
  platformRationale: string;
}

interface ListingCopy {
  poshmarkTitle: string;
  poshmarkDescription: string;
  ebayTitle: string;
  ebayDescription: string;
  etsyTitle: string;
  etsyDescription: string;
  facebookTitle: string;
  facebookDescription: string;
  hashtags: string[];
  measurements: string;
}

// ─── Platform recommendation logic ───────────────────────────────────────────

function recommendPlatform(category: string | null, brand: string | null): string {
  const cat = (category ?? "").toLowerCase();
  const br = (brand ?? "").toLowerCase();

  // Luxury/designer → Poshmark primary
  const luxuryBrands = ["halston", "coach", "kate spade", "michael kors", "tory burch", "ralph lauren", "calvin klein", "donna karan", "dkny", "bcbg", "theory", "vince", "rag & bone", "helmut lang"];
  if (luxuryBrands.some(b => br.includes(b))) return "Poshmark";

  // Vintage/handmade → Etsy
  if (cat.includes("vintage") || cat.includes("handmade")) return "Etsy";

  // Electronics, collectibles → eBay
  if (cat.includes("electronic") || cat.includes("collectible") || cat.includes("tech")) return "eBay";

  // Furniture, home goods → Facebook Marketplace
  if (cat.includes("furniture") || cat.includes("home") || cat.includes("decor")) return "Facebook Marketplace";

  // Default fashion → Poshmark
  return "Poshmark";
}

// ─── Market Pricing ───────────────────────────────────────────────────────────

async function fetchMarketPricing(item: {
  brand: string | null;
  category: string | null;
  style: string | null;
  fabric: string | null;
  color: string | null;
  condition: string | null;
}): Promise<MarketData> {
  const itemDesc = [
    item.brand && item.brand !== "Unknown" ? item.brand : "",
    item.color ?? "",
    item.style ?? item.category ?? "",
    item.fabric && item.fabric !== "Unknown" ? `(${item.fabric})` : "",
    item.condition ? `- ${item.condition}` : "",
  ]
    .filter(Boolean)
    .join(" ");

  const recommendedPlatform = recommendPlatform(item.category, item.brand);

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert resale market analyst with deep knowledge of current pricing on Poshmark, Etsy, eBay, and Facebook Marketplace.
You know current market trends, brand premiums, and typical sell-through rates.
Provide realistic, data-driven pricing based on comparable sold listings.
Do NOT include The RealReal in any results.
Return ONLY valid JSON with no markdown.`,
      },
      {
        role: "user",
        content: `Provide market pricing data for this resale item: "${itemDesc}"

Based on your knowledge of comparable sold listings on Poshmark, Etsy, eBay, and Facebook Marketplace, provide:
1. 4-8 comparable sold listings (focus on Poshmark and eBay primarily, Etsy and Facebook occasionally)
2. A realistic price range for this item in its condition
3. Estimated days to sell at the recommended price
4. Which platform is best for this specific item

Consider:
- Current market demand and trends
- Brand recognition and premium
- Condition impact on pricing
- Platform-specific pricing differences (Poshmark for fashion, eBay for broader reach, Etsy for vintage/unique, Facebook for local/bulky)
- Typical sell-through velocity for this category

Return JSON:
{
  "sources": [
    {
      "platform": "Poshmark|Etsy|eBay|Facebook Marketplace",
      "title": "comparable listing title",
      "price": 45.00,
      "condition": "Like New|Good|etc",
      "url": "https://..."
    }
  ],
  "priceLow": 35.00,
  "priceHigh": 65.00,
  "estimatedDaysToSell": 21,
  "pricingRationale": "Brief explanation of pricing logic",
  "recommendedPlatform": "Poshmark|eBay|Etsy|Facebook Marketplace",
  "platformRationale": "Why this platform is best for this item"
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "market_data",
        strict: true,
        schema: {
          type: "object",
          properties: {
            sources: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  platform: { type: "string" },
                  title: { type: "string" },
                  price: { type: "number" },
                  condition: { type: "string" },
                  url: { type: "string" },
                },
                required: ["platform", "title", "price", "condition", "url"],
                additionalProperties: false,
              },
            },
            priceLow: { type: "number" },
            priceHigh: { type: "number" },
            estimatedDaysToSell: { type: "integer" },
            pricingRationale: { type: "string" },
            recommendedPlatform: { type: "string" },
            platformRationale: { type: "string" },
          },
          required: ["sources", "priceLow", "priceHigh", "estimatedDaysToSell", "pricingRationale", "recommendedPlatform", "platformRationale"],
          additionalProperties: false,
        },
      },
    },
  });

  const rawContent = response.choices[0]?.message?.content;
  const content = Array.isArray(rawContent)
    ? rawContent.map((c: any) => c.text ?? "").join("")
    : rawContent;
  if (!content) throw new Error("No response from market pricing AI");

  const data = JSON.parse(content) as MarketData;
  // Override with our local recommendation if AI didn't give a good one
  if (!data.recommendedPlatform) {
    data.recommendedPlatform = recommendedPlatform;
  }
  return data;
}

// ─── Listing Generator ────────────────────────────────────────────────────────

async function generateListingCopy(item: {
  brand: string | null;
  category: string | null;
  style: string | null;
  fabric: string | null;
  color: string | null;
  condition: string | null;
  description: string | null;
  priceRangeLow: string | null;
  priceRangeHigh: string | null;
}): Promise<ListingCopy> {
  const condition = item.condition ?? "Good";
  const brand = item.brand ?? "Unknown Brand";
  const category = item.category ?? "Item";
  const style = item.style ?? "";
  const color = item.color ?? "";
  const fabric = item.fabric ?? "";
  const priceLow = item.priceRangeLow ? `$${parseFloat(item.priceRangeLow).toFixed(0)}` : "";
  const priceHigh = item.priceRangeHigh ? `$${parseFloat(item.priceRangeHigh).toFixed(0)}` : "";
  const priceRange = priceLow && priceHigh ? `${priceLow}–${priceHigh}` : "";

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert resale listing copywriter who writes high-converting listings for Poshmark, eBay, Etsy, and Facebook Marketplace.
You write titles that are keyword-rich and within character limits.
You write descriptions that are honest, detailed, and buyer-friendly.
Return ONLY valid JSON with no markdown.`,
      },
      {
        role: "user",
        content: `Write resale listing copy for this item:
- Brand: ${brand}
- Category: ${category}
- Style: ${style}
- Color: ${color}
- Fabric/Material: ${fabric}
- Condition: ${condition}
- Additional details: ${item.description ?? "none"}
- Price range: ${priceRange}

Requirements:
- Poshmark title: max 80 characters, keyword-rich, include brand + style + color
- Poshmark description: 3-4 sentences, mention condition honestly, include style notes, end with "All sales final. No trades."
- eBay title: max 80 characters, include brand + item type + color + condition keyword
- eBay description: structured with bullet points for item specifics, condition details, shipping note
- Etsy title: max 140 characters, include "vintage" or style era if applicable, keyword-rich
- Etsy description: warm, story-driven tone, 3-4 sentences, mention materials and condition
- Facebook title: short and punchy, max 60 characters, include price range if available
- Facebook description: casual, local-friendly, 2-3 sentences, mention pickup/shipping options
- Hashtags: 8-10 relevant Poshmark hashtags (no # symbol, just the words)
- Measurements: estimate approximate measurements based on category and style (e.g. "Approx 14"W x 11"H x 4"D" for a bag)

Return JSON:
{
  "poshmarkTitle": "...",
  "poshmarkDescription": "...",
  "ebayTitle": "...",
  "ebayDescription": "...",
  "etsyTitle": "...",
  "etsyDescription": "...",
  "facebookTitle": "...",
  "facebookDescription": "...",
  "hashtags": ["tag1", "tag2"],
  "measurements": "..."
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "listing_copy",
        strict: true,
        schema: {
          type: "object",
          properties: {
            poshmarkTitle: { type: "string" },
            poshmarkDescription: { type: "string" },
            ebayTitle: { type: "string" },
            ebayDescription: { type: "string" },
            etsyTitle: { type: "string" },
            etsyDescription: { type: "string" },
            facebookTitle: { type: "string" },
            facebookDescription: { type: "string" },
            hashtags: { type: "array", items: { type: "string" } },
            measurements: { type: "string" },
          },
          required: ["poshmarkTitle", "poshmarkDescription", "ebayTitle", "ebayDescription", "etsyTitle", "etsyDescription", "facebookTitle", "facebookDescription", "hashtags", "measurements"],
          additionalProperties: false,
        },
      },
    },
  });

  const rawContent = response.choices[0]?.message?.content;
  const content = Array.isArray(rawContent)
    ? rawContent.map((c: any) => c.text ?? "").join("")
    : rawContent;
  if (!content) throw new Error("No response from listing copy AI");
  return JSON.parse(content) as ListingCopy;
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const itemRouter = router({
  /**
   * Fetch market pricing for a single item and save to DB.
   */
  fetchPricing: protectedProcedure
    .input(z.object({ itemId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.itemId);
      if (!item) throw new TRPCError({ code: "NOT_FOUND" });

      const batch = await getBatchById(item.batchId);
      if (!batch || batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const marketData = await fetchMarketPricing({
        brand: item.brand,
        category: item.category,
        style: item.style,
        fabric: item.fabric,
        color: item.color,
        condition: item.manualCondition ?? item.condition,
      });

      await updateItem(input.itemId, {
        priceRangeLow: marketData.priceLow.toFixed(2),
        priceRangeHigh: marketData.priceHigh.toFixed(2),
        estimatedDaysToSell: marketData.estimatedDaysToSell,
        marketSources: marketData.sources,
        recommendedPlatform: marketData.recommendedPlatform,
      });

      return {
        priceLow: marketData.priceLow,
        priceHigh: marketData.priceHigh,
        estimatedDaysToSell: marketData.estimatedDaysToSell,
        sources: marketData.sources,
        pricingRationale: marketData.pricingRationale,
        recommendedPlatform: marketData.recommendedPlatform,
        platformRationale: marketData.platformRationale,
      };
    }),

  /**
   * Fetch pricing for all items in a batch.
   */
  fetchBatchPricing: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const batchItems = await getItemsByBatch(input.batchId);
      const results: { itemId: number; priceLow: number; priceHigh: number; estimatedDaysToSell: number; recommendedPlatform: string }[] = [];

      for (const item of batchItems) {
        try {
          const marketData = await fetchMarketPricing({
            brand: item.brand,
            category: item.category,
            style: item.style,
            fabric: item.fabric,
            color: item.color,
            condition: item.manualCondition ?? item.condition,
          });

          await updateItem(item.id, {
            priceRangeLow: marketData.priceLow.toFixed(2),
            priceRangeHigh: marketData.priceHigh.toFixed(2),
            estimatedDaysToSell: marketData.estimatedDaysToSell,
            marketSources: marketData.sources,
            recommendedPlatform: marketData.recommendedPlatform,
          });

          results.push({
            itemId: item.id,
            priceLow: marketData.priceLow,
            priceHigh: marketData.priceHigh,
            estimatedDaysToSell: marketData.estimatedDaysToSell,
            recommendedPlatform: marketData.recommendedPlatform,
          });
        } catch (err) {
          console.error(`[Pricing] Failed for item ${item.id}:`, err);
        }
      }

      return { success: true, results };
    }),

  /**
   * Generate listing copy for a single item (Poshmark, eBay, Etsy, Facebook).
   */
  generateListings: protectedProcedure
    .input(z.object({ itemId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.itemId);
      if (!item) throw new TRPCError({ code: "NOT_FOUND" });

      const batch = await getBatchById(item.batchId);
      if (!batch || batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const listingCopy = await generateListingCopy({
        brand: item.brand,
        category: item.category,
        style: item.style,
        fabric: item.fabric,
        color: item.color,
        condition: item.manualCondition ?? item.condition,
        description: item.description,
        priceRangeLow: item.manualPriceLow ?? item.priceRangeLow,
        priceRangeHigh: item.manualPriceHigh ?? item.priceRangeHigh,
      });

      await updateItem(input.itemId, {
        listingCopy: listingCopy,
      });

      return listingCopy;
    }),

  /**
   * Generate listing copy for all items in a batch.
   */
  generateBatchListings: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const batchItems = await getItemsByBatch(input.batchId);
      let successCount = 0;

      for (const item of batchItems) {
        try {
          const listingCopy = await generateListingCopy({
            brand: item.brand,
            category: item.category,
            style: item.style,
            fabric: item.fabric,
            color: item.color,
            condition: item.manualCondition ?? item.condition,
            description: item.description,
            priceRangeLow: item.manualPriceLow ?? item.priceRangeLow,
            priceRangeHigh: item.manualPriceHigh ?? item.priceRangeHigh,
          });

          await updateItem(item.id, { listingCopy });
          successCount++;
        } catch (err) {
          console.error(`[Listings] Failed for item ${item.id}:`, err);
        }
      }

      return { success: true, successCount };
    }),

  /**
   * Update item fields (manual overrides for condition, price, notes, attributes).
   */
  update: protectedProcedure
    .input(
      z.object({
        itemId: z.number(),
        brand: z.string().optional(),
        category: z.string().optional(),
        style: z.string().optional(),
        fabric: z.string().optional(),
        color: z.string().optional(),
        description: z.string().optional(),
        manualCondition: z.enum(["New", "Like New", "Good", "Fair"]).optional(),
        manualPriceLow: z.number().optional(),
        manualPriceHigh: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.itemId);
      if (!item) throw new TRPCError({ code: "NOT_FOUND" });

      const batch = await getBatchById(item.batchId);
      if (!batch || batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const { itemId, manualPriceLow, manualPriceHigh, ...rest } = input;
      await updateItem(itemId, {
        ...rest,
        ...(manualPriceLow !== undefined ? { manualPriceLow: manualPriceLow.toFixed(2) } : {}),
        ...(manualPriceHigh !== undefined ? { manualPriceHigh: manualPriceHigh.toFixed(2) } : {}),
      });

      return { success: true };
    }),

  /**
   * Get a single item with its photos.
   */
  get: protectedProcedure
    .input(z.object({ itemId: z.number() }))
    .query(async ({ ctx, input }) => {
      const item = await getItemById(input.itemId);
      if (!item) throw new TRPCError({ code: "NOT_FOUND" });
      const batch = await getBatchById(item.batchId);
      if (!batch || batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      return item;
    }),
});
