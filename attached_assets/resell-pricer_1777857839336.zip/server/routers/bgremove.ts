import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getBatchById,
  getItemPhotosByBatch,
  updateItemPhoto,
} from "../db";
import { generateImage } from "../_core/imageGeneration";
import { storagePut } from "../storage";
import { nanoid } from "nanoid";

// ─── Constants ────────────────────────────────────────────────────────────────

const CONCURRENCY = 3;       // Process 3 photos simultaneously
const PHOTO_TIMEOUT_MS = 45_000; // 45s per photo max

// ─── Helpers ──────────────────────────────────────────────────────────────────

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error(`Timeout after ${ms / 1000}s: ${label}`)), ms)
    ),
  ]);
}

async function removeBackground(
  originalUrl: string,
  s3KeyPrefix: string
): Promise<{ cleanedUrl: string; cleanedS3Key: string }> {
  const result = await generateImage({
    prompt:
      "Remove the background completely. Replace it with a clean white background. Keep the item exactly as-is — do not alter colors, shape, texture, or any details of the item itself. The result should look like a professional product photo on a pure white background.",
    originalImages: [{ url: originalUrl, mimeType: "image/jpeg" }],
  });

  if (!result.url) throw new Error("Background removal returned no image URL");

  const cleanedS3Key = `${s3KeyPrefix}/cleaned-${nanoid(8)}.png`;
  const response = await fetch(result.url);
  if (!response.ok) throw new Error("Failed to fetch generated image");
  const buffer = Buffer.from(await response.arrayBuffer());
  const { url: cleanedUrl } = await storagePut(cleanedS3Key, buffer, "image/png");

  return { cleanedUrl, cleanedS3Key };
}

/**
 * Run tasks with a concurrency limit.
 * Returns results in order, with null for failed tasks.
 */
async function pLimit<T>(
  tasks: (() => Promise<T>)[],
  concurrency: number
): Promise<(T | null)[]> {
  const results: (T | null)[] = new Array(tasks.length).fill(null);
  let index = 0;

  async function worker() {
    while (index < tasks.length) {
      const i = index++;
      try {
        results[i] = await tasks[i]!();
      } catch {
        results[i] = null;
      }
    }
  }

  const workers = Array.from({ length: Math.min(concurrency, tasks.length) }, worker);
  await Promise.all(workers);
  return results;
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const bgremoveRouter = router({
  /**
   * Remove background from all item photos in a batch.
   * Runs up to CONCURRENCY photos in parallel with per-photo timeout.
   */
  processBatch: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const allPhotos = await getItemPhotosByBatch(input.batchId);
      if (allPhotos.length === 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "No item photos found. Process the batch first.",
        });
      }

      // Only process photos that haven't been cleaned yet
      const pending = allPhotos.filter((p) => !p.cleanedUrl);
      const alreadyDone = allPhotos.length - pending.length;

      const errors: string[] = [];
      let successCount = alreadyDone;

      const tasks = pending.map((photo) => async () => {
        const { cleanedUrl, cleanedS3Key } = await withTimeout(
          removeBackground(photo.url, `batches/${input.batchId}/cleaned`),
          PHOTO_TIMEOUT_MS,
          `photo ${photo.id}`
        );
        await updateItemPhoto(photo.id, { cleanedUrl, cleanedS3Key });
        successCount++;
        return photo.id;
      });

      // Run with concurrency limit — errors are caught per-task
      const taskResults = await pLimit(
        tasks.map((task, i) => async () => {
          try {
            return await task();
          } catch (err) {
            const msg = err instanceof Error ? err.message : "Unknown error";
            errors.push(`Photo ${pending[i]?.id}: ${msg}`);
            console.error(`[BgRemove] Failed photo ${pending[i]?.id}:`, err);
            return null;
          }
        }),
        CONCURRENCY
      );

      const failCount = taskResults.filter((r) => r === null).length;

      return {
        success: true,
        totalPhotos: allPhotos.length,
        successCount,
        failCount,
        errors: errors.slice(0, 5),
      };
    }),

  /**
   * Remove background from a single item photo.
   */
  processPhoto: protectedProcedure
    .input(z.object({ photoId: z.number(), batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const allPhotos = await getItemPhotosByBatch(input.batchId);
      const photo = allPhotos.find((p) => p.id === input.photoId);
      if (!photo) throw new TRPCError({ code: "NOT_FOUND", message: "Photo not found" });

      try {
        const { cleanedUrl, cleanedS3Key } = await withTimeout(
          removeBackground(photo.url, `batches/${input.batchId}/cleaned`),
          PHOTO_TIMEOUT_MS,
          `photo ${photo.id}`
        );
        await updateItemPhoto(photo.id, { cleanedUrl, cleanedS3Key });
        return { success: true, cleanedUrl };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Background removal failed";
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: msg });
      }
    }),

  /**
   * Get background removal status for a batch.
   */
  status: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .query(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const allPhotos = await getItemPhotosByBatch(input.batchId);
      const cleaned = allPhotos.filter((p) => p.cleanedUrl).length;

      return {
        total: allPhotos.length,
        cleaned,
        pending: allPhotos.length - cleaned,
        isComplete: cleaned === allPhotos.length && allPhotos.length > 0,
      };
    }),
});
