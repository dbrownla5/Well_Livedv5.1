import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  createBatch,
  getBatchById,
  getBatchesByUser,
  updateBatchStatus,
  deleteBatch,
  addBatchPhoto,
  getBatchPhotos,
  createItem,
  addItemPhoto,
  getItemsByBatch,
  getItemPhotosByBatch,
} from "../db";
import { storagePut } from "../storage";
import { invokeLLM, type Message } from "../_core/llm";
import { nanoid } from "nanoid";

// ─── Types ────────────────────────────────────────────────────────────────────

interface GroupedItem {
  photoUrls: string[];
  photoIndices: number[];
}

interface DetectedAttributes {
  brand: string;
  category: string;
  style: string;
  fabric: string;
  color: string;
  description: string;
  condition: "New" | "Like New" | "Good" | "Fair";
  conditionNotes: string;
  angleLabels: string[];
}

// ─── AI Helpers ───────────────────────────────────────────────────────────────

async function groupPhotosByItem(photoUrls: string[]): Promise<GroupedItem[]> {
  const imageContents = photoUrls.map((url) => ({
    type: "image_url" as const,
    image_url: { url, detail: "low" as const },
  }));

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert at identifying fashion and consumer goods items from photos.
You will receive a batch of photos (typically 15-25 photos) showing approximately 3-5 different items.
Each item has been photographed from 3-4 different angles (front, back, label/tag, detail).
Your task is to group the photo indices by item.
Return ONLY valid JSON with no markdown, no explanation.`,
      },
      {
        role: "user",
        content: [
          {
            type: "text" as const,
            text: `I have ${photoUrls.length} photos (indices 0 to ${photoUrls.length - 1}).
Group them by item. Each item should have 2-5 photos showing different angles of the same physical item.
Return JSON in this exact format:
{
  "groups": [
    { "photoIndices": [0, 1, 2, 3] },
    { "photoIndices": [4, 5, 6] },
    ...
  ]
}`,
          },
          ...imageContents,
        ] as Message["content"],
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "photo_groups",
        strict: true,
        schema: {
          type: "object",
          properties: {
            groups: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  photoIndices: {
                    type: "array",
                    items: { type: "integer" },
                  },
                },
                required: ["photoIndices"],
                additionalProperties: false,
              },
            },
          },
          required: ["groups"],
          additionalProperties: false,
        },
      },
    },
  });

  const rawContent = response.choices[0]?.message?.content;
  const content = Array.isArray(rawContent) ? rawContent.map((c: any) => c.text ?? "").join("") : rawContent;
  if (!content) throw new Error("No response from AI grouping");
  const parsed = JSON.parse(content) as { groups: { photoIndices: number[] }[] };;
  return parsed.groups.map((g) => ({
    photoIndices: g.photoIndices,
    photoUrls: g.photoIndices.map((i) => photoUrls[i]).filter(Boolean) as string[],
  }));
}

async function detectItemAttributes(photoUrls: string[]): Promise<DetectedAttributes> {
  const imageContents = photoUrls.slice(0, 4).map((url) => ({
    type: "image_url" as const,
    image_url: { url, detail: "high" as const },
  }));

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert fashion and consumer goods appraiser with deep knowledge of brands, fabrics, styles, and market conditions.
Analyze the provided photos of a single item and extract detailed attributes.
Be specific and accurate — this data will be used for resale pricing.
Return ONLY valid JSON with no markdown.`,
      },
      {
        role: "user",
        content: [
          {
            type: "text" as const,
            text: `Analyze these photos of a single resale item and return its attributes.
For condition, use visible wear, tags, and overall state. Be honest and conservative.
For angleLabels, describe what each photo shows (e.g., "front", "back", "label", "detail", "sole", "interior").

Return JSON:
{
  "brand": "brand name or Unknown",
  "category": "e.g. Dress, Handbag, Sneakers, Jacket, Jeans, Electronics, etc.",
  "style": "e.g. Midi Dress, Crossbody Bag, High-Top Sneaker, Blazer, Skinny Jeans",
  "fabric": "e.g. 100% Silk, Cotton Blend, Full-Grain Leather, Polyester, or Unknown",
  "color": "primary color(s)",
  "description": "2-3 sentence description for a listing",
  "condition": "New | Like New | Good | Fair",
  "conditionNotes": "brief notes on visible wear or flaws, or empty string",
  "angleLabels": ["label for photo 1", "label for photo 2", ...]
}`,
          },
          ...imageContents,
        ] as Message["content"],
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "item_attributes",
        strict: true,
        schema: {
          type: "object",
          properties: {
            brand: { type: "string" },
            category: { type: "string" },
            style: { type: "string" },
            fabric: { type: "string" },
            color: { type: "string" },
            description: { type: "string" },
            condition: { type: "string", enum: ["New", "Like New", "Good", "Fair"] },
            conditionNotes: { type: "string" },
            angleLabels: { type: "array", items: { type: "string" } },
          },
          required: ["brand", "category", "style", "fabric", "color", "description", "condition", "conditionNotes", "angleLabels"],
          additionalProperties: false,
        },
      },
    },
  });

  const rawContent = response.choices[0]?.message?.content;
  const content = Array.isArray(rawContent) ? rawContent.map((c: any) => c.text ?? "").join("") : rawContent;
  if (!content) throw new Error("No response from AI attribute detection");
  return JSON.parse(content) as DetectedAttributes;
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const batchRouter = router({
  /**
   * Create a new batch and upload photos to S3.
   * Accepts base64-encoded photos.
   */
  create: protectedProcedure
    .input(
      z.object({
        consigneeClient: z.string().min(1),
        photos: z.array(
          z.object({
            filename: z.string(),
            mimeType: z.string(),
            base64: z.string(),
          })
        ).min(1).max(25),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // 1. Create batch record
      const batchId = await createBatch({
        userId: ctx.user.id,
        consigneeClient: input.consigneeClient,
        status: "uploading",
      });

      // 2. Upload each photo to S3
      const uploadedPhotos: { url: string; s3Key: string; filename: string }[] = [];
      for (let i = 0; i < input.photos.length; i++) {
        const photo = input.photos[i];
        const suffix = nanoid(8);
        const s3Key = `batches/${batchId}/raw/${i}-${suffix}-${photo.filename}`;
        const buffer = Buffer.from(photo.base64, "base64");
        const { url } = await storagePut(s3Key, buffer, photo.mimeType);
        await addBatchPhoto({
          batchId,
          s3Key,
          url,
          originalFilename: photo.filename,
          sortOrder: i,
        });
        uploadedPhotos.push({ url, s3Key, filename: photo.filename });
      }

      await updateBatchStatus(batchId, "processing");
      return { batchId, photoCount: uploadedPhotos.length };
    }),

  /**
   * Run AI processing on an uploaded batch:
   * 1. Group photos by item
   * 2. Detect attributes for each item
   * 3. Save items and item photos to DB
   */
  process: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND", message: "Batch not found" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      try {
        // 1. Get all uploaded photos
        const rawPhotos = await getBatchPhotos(input.batchId);
        const photoUrls = rawPhotos.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)).map((p) => p.url);

        if (photoUrls.length === 0) throw new Error("No photos found in batch");

        // 2. Group photos by item using vision AI
        const groups = await groupPhotosByItem(photoUrls);

        // 3. For each group, detect attributes and save item
        const createdItems: number[] = [];
        for (let i = 0; i < groups.length; i++) {
          const group = groups[i];
          if (!group || group.photoUrls.length === 0) continue;

          // Detect attributes
          const attrs = await detectItemAttributes(group.photoUrls);

          // Save item
          const itemId = await createItem({
            batchId: input.batchId,
            itemIndex: i,
            brand: attrs.brand,
            category: attrs.category,
            style: attrs.style,
            fabric: attrs.fabric,
            color: attrs.color,
            description: attrs.description,
            condition: attrs.condition,
            conditionNotes: attrs.conditionNotes,
          });

          // Save item photos
          for (let j = 0; j < group.photoIndices.length; j++) {
            const photoIdx = group.photoIndices[j];
            const rawPhoto = rawPhotos[photoIdx ?? 0];
            if (!rawPhoto) continue;
            await addItemPhoto({
              itemId,
              batchId: input.batchId,
              s3Key: rawPhoto.s3Key,
              url: rawPhoto.url,
              originalFilename: rawPhoto.originalFilename ?? undefined,
              angleLabel: attrs.angleLabels[j] ?? "photo",
              sortOrder: j,
            });
          }

          createdItems.push(itemId);
        }

        await updateBatchStatus(input.batchId, "review");
        return { success: true, itemCount: createdItems.length, itemIds: createdItems };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        await updateBatchStatus(input.batchId, "error", { errorMessage: msg });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: msg });
      }
    }),

  /**
   * Get a batch with all its items and photos.
   */
  get: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .query(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const batchItems = await getItemsByBatch(input.batchId);
      const allPhotos = await getItemPhotosByBatch(input.batchId);

      const itemsWithPhotos = batchItems.map((item) => ({
        ...item,
        photos: allPhotos.filter((p) => p.itemId === item.id).sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)),
      }));

      return { ...batch, items: itemsWithPhotos };
    }),

  /**
   * List all batches for the current user.
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    return getBatchesByUser(ctx.user.id);
  }),

  /**
   * Delete a batch and all associated data.
   */
  delete: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      await deleteBatch(input.batchId);
      return { success: true };
    }),
});
