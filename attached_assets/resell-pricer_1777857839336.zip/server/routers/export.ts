import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getBatchById, getItemsByBatch, getItemPhotosByBatch, updateBatchStatus } from "../db";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

// ─── Google Sheets Export ─────────────────────────────────────────────────────

async function createSpreadsheet(title: string): Promise<string> {
  const body = JSON.stringify({
    properties: { title },
    sheets: [{ properties: { title: "Inventory" } }],
  });
  const result = await execAsync(
    `gws sheets spreadsheets create --json '${body.replace(/'/g, "'\\''")}'`
  );
  const data = JSON.parse(result.stdout);
  return data.spreadsheetId as string;
}

async function updateSheetData(spreadsheetId: string, values: string[][]): Promise<void> {
  // Sanitize all values: remove newlines, escape single quotes
  const sanitized = values.map((row) =>
    row.map((cell) => cell.replace(/[\r\n]+/g, " ").replace(/'/g, "\\'"))
  );

  const body = JSON.stringify({
    values: sanitized,
  });

  await execAsync(
    `gws sheets spreadsheets values update --params '{"spreadsheetId":"${spreadsheetId}","range":"Inventory!A1","valueInputOption":"USER_ENTERED"}' --json '${body.replace(/'/g, "'\\''")}'`
  );
}

async function formatHeaderRow(spreadsheetId: string, sheetId: number): Promise<void> {
  const body = JSON.stringify({
    requests: [
      {
        repeatCell: {
          range: {
            sheetId,
            startRowIndex: 0,
            endRowIndex: 1,
          },
          cell: {
            userEnteredFormat: {
              backgroundColor: { red: 0.2, green: 0.2, blue: 0.2 },
              textFormat: {
                foregroundColor: { red: 1, green: 1, blue: 1 },
                bold: true,
                fontSize: 11,
              },
            },
          },
          fields: "userEnteredFormat(backgroundColor,textFormat)",
        },
      },
      {
        autoResizeDimensions: {
          dimensions: {
            sheetId,
            dimension: "COLUMNS",
            startIndex: 0,
            endIndex: 24,
          },
        },
      },
    ],
  });

  await execAsync(
    `gws sheets spreadsheets batchUpdate --params '{"spreadsheetId":"${spreadsheetId}"}' --json '${body.replace(/'/g, "'\\''")}'`
  );
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const exportRouter = router({
  /**
   * Export a batch to a new Google Sheet and save the URL.
   */
  toSheets: protectedProcedure
    .input(z.object({ batchId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const batch = await getBatchById(input.batchId);
      if (!batch) throw new TRPCError({ code: "NOT_FOUND" });
      if (batch.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      const batchItems = await getItemsByBatch(input.batchId);
      if (batchItems.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "No items to export" });
      }

      try {
        // 1. Create spreadsheet
        const sheetTitle = `Consignment - ${batch.consigneeClient} - ${new Date(batch.createdAt).toLocaleDateString("en-US")}`;
        const spreadsheetId = await createSpreadsheet(sheetTitle);

        // 2. Build rows
        const headers = [
          "Item #",
          "Consignee Client",
          "Brand",
          "Category",
          "Style",
          "Fabric",
          "Color",
          "Condition",
          "Condition Notes",
          "Price Low ($)",
          "Price High ($)",
          "Est. Days to Sell",
          "Recommended Platform",
          "Poshmark Title",
          "Poshmark Description",
          "eBay Title",
          "eBay Description",
          "Etsy Title",
          "Facebook Title",
          "Measurements",
          "Hashtags",
          "Description",
          "Notes",
        ];

        const rows: string[][] = [headers];

        for (let i = 0; i < batchItems.length; i++) {
          const item = batchItems[i];
          if (!item) continue;

          // Use manual overrides if set, otherwise AI values
          const effectiveCondition = item.manualCondition ?? item.condition ?? "Good";
          const effectivePriceLow = item.manualPriceLow ?? item.priceRangeLow ?? "0.00";
          const effectivePriceHigh = item.manualPriceHigh ?? item.priceRangeHigh ?? "0.00";

          const lc = (item.listingCopy as any) ?? {};

          rows.push([
            String(i + 1),
            batch.consigneeClient,
            item.brand ?? "",
            item.category ?? "",
            item.style ?? "",
            item.fabric ?? "",
            item.color ?? "",
            effectiveCondition,
            item.conditionNotes ?? "",
            String(effectivePriceLow),
            String(effectivePriceHigh),
            item.estimatedDaysToSell ? String(item.estimatedDaysToSell) : "",
            item.recommendedPlatform ?? "",
            lc.poshmarkTitle ?? "",
            lc.poshmarkDescription ?? "",
            lc.ebayTitle ?? "",
            lc.ebayDescription ?? "",
            lc.etsyTitle ?? "",
            lc.facebookTitle ?? "",
            lc.measurements ?? "",
            Array.isArray(lc.hashtags) ? lc.hashtags.map((h: string) => `#${h}`).join(" ") : "",
            item.description ?? "",
            item.notes ?? "",
          ]);
        }

        // 3. Write data
        await updateSheetData(spreadsheetId, rows);

        // 4. Format header
        await formatHeaderRow(spreadsheetId, 0);

        // 5. Save sheet URL to batch
        const sheetsUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}`;
        await updateBatchStatus(input.batchId, "exported", { sheetsUrl });

        return { success: true, sheetsUrl, spreadsheetId };
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Export failed";
        console.error("[Export] Google Sheets export failed:", err);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: msg });
      }
    }),
});
