import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  batches,
  items,
  itemPhotos,
  batchPhotos,
  InsertBatch,
  InsertItem,
  InsertItemPhoto,
  InsertBatchPhoto,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Batches ──────────────────────────────────────────────────────────────────

export async function createBatch(data: InsertBatch) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(batches).values(data);
  return result[0].insertId as number;
}

export async function getBatchById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.select().from(batches).where(eq(batches.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getBatchesByUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.select().from(batches).where(eq(batches.userId, userId)).orderBy(desc(batches.createdAt));
}

export async function updateBatchStatus(
  id: number,
  status: "uploading" | "processing" | "review" | "exported" | "error",
  extra?: { sheetsUrl?: string; errorMessage?: string }
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .update(batches)
    .set({ status, ...extra })
    .where(eq(batches.id, id));
}

export async function deleteBatch(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(batchPhotos).where(eq(batchPhotos.batchId, id));
  await db.delete(itemPhotos).where(eq(itemPhotos.batchId, id));
  await db.delete(items).where(eq(items.batchId, id));
  await db.delete(batches).where(eq(batches.id, id));
}

// ─── Batch Photos (unprocessed) ───────────────────────────────────────────────

export async function addBatchPhoto(data: InsertBatchPhoto) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(batchPhotos).values(data);
  return result[0].insertId as number;
}

export async function getBatchPhotos(batchId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.select().from(batchPhotos).where(eq(batchPhotos.batchId, batchId));
}

// ─── Items ────────────────────────────────────────────────────────────────────

export async function createItem(data: InsertItem) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(items).values(data);
  return result[0].insertId as number;
}

export async function getItemsByBatch(batchId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.select().from(items).where(eq(items.batchId, batchId));
}

export async function getItemById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.select().from(items).where(eq(items.id, id)).limit(1);
  return result[0] ?? null;
}

export async function updateItem(
  id: number,
  data: Partial<{
    brand: string;
    category: string;
    style: string;
    fabric: string;
    color: string;
    description: string;
    condition: "New" | "Like New" | "Good" | "Fair";
    conditionNotes: string;
    priceRangeLow: string;
    priceRangeHigh: string;
    estimatedDaysToSell: number;
    marketSources: unknown;
    recommendedPlatform: string;
    listingCopy: unknown;
    manualCondition: "New" | "Like New" | "Good" | "Fair";
    manualPriceLow: string;
    manualPriceHigh: string;
    notes: string;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(items).set(data).where(eq(items.id, id));
}

// ─── Item Photos ──────────────────────────────────────────────────────────────

export async function addItemPhoto(data: InsertItemPhoto) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(itemPhotos).values(data);
  return result[0].insertId as number;
}

export async function getItemPhotos(itemId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.select().from(itemPhotos).where(eq(itemPhotos.itemId, itemId));
}

export async function getItemPhotosByBatch(batchId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db.select().from(itemPhotos).where(eq(itemPhotos.batchId, batchId));
}

export async function updateItemPhoto(
  id: number,
  data: Partial<{ cleanedUrl: string; cleanedS3Key: string; angleLabel: string }>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(itemPhotos).set(data).where(eq(itemPhotos.id, id));
}

export async function updateBatchPhoto(
  id: number,
  data: Partial<{ cleanedUrl: string; cleanedS3Key: string }>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(batchPhotos).set(data).where(eq(batchPhotos.id, id));
}
