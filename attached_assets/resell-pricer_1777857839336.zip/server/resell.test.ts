import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock context helpers ─────────────────────────────────────────────────────

function makeCtx(overrides?: Partial<TrpcContext>): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
    ...overrides,
  };
}

// ─── Auth tests ───────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns the current user when authenticated", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeTruthy();
    expect(result?.email).toBe("test@example.com");
  });

  it("returns null when unauthenticated", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });
});

describe("auth.logout", () => {
  it("clears the session cookie and returns success", async () => {
    const clearedCookies: string[] = [];
    const ctx = makeCtx({
      res: {
        clearCookie: (name: string) => { clearedCookies.push(name); },
      } as TrpcContext["res"],
    });
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(clearedCookies.length).toBeGreaterThan(0);
  });
});

// ─── Batch router tests ───────────────────────────────────────────────────────

describe("batch.list", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.batch.list()).rejects.toThrow();
  });
});

describe("batch.get", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.batch.get({ batchId: 1 })).rejects.toThrow();
  });

  it("throws NOT_FOUND for non-existent batch", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.batch.get({ batchId: 999999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});

describe("batch.delete", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.batch.delete({ batchId: 1 })).rejects.toThrow();
  });
});

// ─── Item router tests ────────────────────────────────────────────────────────

describe("item.get", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.get({ itemId: 1 })).rejects.toThrow();
  });

  it("throws NOT_FOUND for non-existent item", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.get({ itemId: 999999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});

describe("item.update", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.update({ itemId: 1, brand: "Test" })).rejects.toThrow();
  });
});

// ─── Listing generator tests ────────────────────────────────────────────────

describe("item.generateListings", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.generateListings({ itemId: 1 })).rejects.toThrow();
  });

  it("throws NOT_FOUND for non-existent item", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.generateListings({ itemId: 999999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});

describe("item.generateBatchListings", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.generateBatchListings({ batchId: 1 })).rejects.toThrow();
  });

  it("throws NOT_FOUND for non-existent batch", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.item.generateBatchListings({ batchId: 999999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});

// ─── Export router tests ──────────────────────────────────────────────────────

describe("export.toSheets", () => {
  it("requires authentication", async () => {
    const ctx = makeCtx({ user: null });
    const caller = appRouter.createCaller(ctx);
    await expect(caller.export.toSheets({ batchId: 1 })).rejects.toThrow();
  });

  it("throws NOT_FOUND for non-existent batch", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.export.toSheets({ batchId: 999999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});
