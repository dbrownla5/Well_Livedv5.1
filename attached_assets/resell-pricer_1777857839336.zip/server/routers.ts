import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { batchRouter } from "./routers/batch";
import { itemRouter } from "./routers/item";
import { exportRouter } from "./routers/export";
import { bgremoveRouter } from "./routers/bgremove";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  batch: batchRouter,
  item: itemRouter,
  export: exportRouter,
  bgremove: bgremoveRouter,
});

export type AppRouter = typeof appRouter;
