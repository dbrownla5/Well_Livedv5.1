# The Well Lived Citizen Co — Site Deploy Instructions

## Files in this folder

```
index.html          → Homepage (/)
about.html          → About (/about)
services.html       → Services overview (/services)
pricing.html        → Pricing (/pricing)
contact.html        → Contact (/contact)
services/
  home-organization.html  → /services/home-organization
  legacy.html             → /services/legacy
  house-calls.html        → /services/house-calls
  resale.html             → /services/resale
style.css           → Shared stylesheet (all pages link to this)
sitemap.xml         → Submit to Google Search Console after deploy
robots.txt          → Allow crawling
images/             → PUT LOGO AND DAYNA PHOTO HERE
  logo-black.png    ← Required: logo on cream background
  logo-white.png    ← Required: logo on dark background  
  dayna.jpg         ← Required: Dayna's photo for About page
```

## Before deploying

1. Add logo files to /images/ folder (provided by Dayna)
2. Add Dayna's photo to /images/dayna.jpg (provided by Dayna)
3. Update contact form action URL in contact.html:
   - Find: `action="https://formspree.io/f/YOUR_FORM_ID"`
   - Replace with actual Formspree endpoint

## Deploy to Netlify (easiest)

1. Drag this entire folder to netlify.com/drop
2. Site is live instantly
3. Connect custom domain: thewelllivedcitizenco.com
4. Done

## After deploy

1. Submit sitemap.xml in Google Search Console
2. Verify Search Console ownership
3. Confirm GA4 tag G-HN9C986JLW is receiving data

## DO NOT

- Do not add any pages not in this list
- Do not rename any service pages
- Do not change any copy
- Do not add images that Dayna did not provide
- Do not modify the sitemap to include pages not listed above
