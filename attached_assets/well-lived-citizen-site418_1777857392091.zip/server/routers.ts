import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { getBusinessInfo, upsertBusinessInfo } from "./db";

const businessInfoInputSchema = z.object({
  businessName: z.string(),
  legalEntity: z.string(),
  city: z.string(),
  serviceArea: z.string(),
  primaryPhone: z.string(),
  primaryPhoneRaw: z.string(),
  workingPhone: z.string(),
  workingPhoneRaw: z.string(),
  zellePhone: z.string(),
  zellePhoneRaw: z.string(),
  primaryEmail: z.string(),
  zelleEmail: z.string(),
  venmoHandle: z.string(),
  stripePaymentLink: z.string(),
  calendarLink: z.string(),
  instagramMain: z.string(),
  instagramCloset: z.string(),
  instagramArchive: z.string(),
  facebook: z.string(),
  poshmarkUrl: z.string(),
  ebayUrl: z.string(),
  responseTime: z.string(),
  hoursNote: z.string(),
  paymentNote: z.string(),
  homeOrganizationSummary: z.string(),
  legacySummary: z.string(),
  houseCallsSummary: z.string(),
  resaleSummary: z.string(),
});

const businessInfoRouter = router({
  get: publicProcedure.query(async () => {
    const existing = await getBusinessInfo();
    if (existing) {
      return existing;
    }

    await upsertBusinessInfo({});
    return (await getBusinessInfo()) ?? (await upsertBusinessInfo({}));
  }),
  update: adminProcedure.input(businessInfoInputSchema).mutation(async ({ input }) => {
    await upsertBusinessInfo(input);
    return (await getBusinessInfo()) ?? (await upsertBusinessInfo(input));
  }),
});

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  businessInfo: businessInfoRouter,
});

export type AppRouter = typeof appRouter;
