import { beforeEach, describe, expect, it, vi } from "vitest";
import { NOT_ADMIN_ERR_MSG } from "../shared/const";
import type { TrpcContext } from "./_core/context";
import { appRouter } from "./routers";
import { patchRecoveredHtml } from "./publicSite";
import { getBusinessInfo, upsertBusinessInfo } from "./db";

vi.mock("./db", () => ({
  getBusinessInfo: vi.fn(),
  upsertBusinessInfo: vi.fn(),
}));

const baseBusinessInfo = {
  id: 1,
  businessName: "The Well Lived Citizen",
  legalEntity: "Well Dressed Citizen LLC",
  city: "Los Angeles",
  serviceArea: "Los Angeles and surrounding areas.",
  primaryPhone: "(323) 433-1350",
  primaryPhoneRaw: "3234331350",
  workingPhone: "(310) 993-0204",
  workingPhoneRaw: "3109930204",
  zellePhone: "(310) 993-0204",
  zellePhoneRaw: "3109930204",
  primaryEmail: "dayna@thewelllivedcitizen.com",
  zelleEmail: "dayna@thewelllivedcitizen.com",
  venmoHandle: "",
  stripePaymentLink: "",
  calendarLink: "",
  instagramMain: "https://instagram.com/thewelllivedcitizen",
  instagramCloset: "https://instagram.com/thewelllivedcloset",
  instagramArchive: "https://instagram.com/welldressedcitizen",
  facebook: "https://facebook.com/thewelllivedcitizen",
  poshmarkUrl: "https://posh.mk/HLUmmsrzq2b",
  ebayUrl: "https://ebay.us/m/cUjlUb",
  responseTime: "Within 24 hours. Text for urgent requests.",
  hoursNote: "By appointment. Text for urgent requests.",
  paymentNote: "Zelle using the email below.",
  homeOrganizationSummary: "Home Organization & Modern Move",
  legacySummary: "Legacy Planning & Inventory Catalog",
  houseCallsSummary: "House Calls",
  resaleSummary: "Curated Resale & Consignment",
  createdAt: new Date(),
  updatedAt: new Date(),
};

function createContext(role: "admin" | "user" | null): TrpcContext {
  return {
    user: role
      ? {
          id: 1,
          openId: `${role}-open-id`,
          email: `${role}@example.com`,
          name: role === "admin" ? "Owner" : "Viewer",
          loginMethod: "manus",
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        }
      : null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("businessInfo router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns the current business info record from the public query", async () => {
    vi.mocked(getBusinessInfo).mockResolvedValue(baseBusinessInfo as never);

    const caller = appRouter.createCaller(createContext(null));
    const result = await caller.businessInfo.get();

    expect(getBusinessInfo).toHaveBeenCalledTimes(1);
    expect(result.businessName).toBe("The Well Lived Citizen");
    expect(result.primaryPhoneRaw).toBe("3234331350");
  });

  it("allows an admin to update the business info record", async () => {
    vi.mocked(upsertBusinessInfo).mockResolvedValue(baseBusinessInfo as never);
    vi.mocked(getBusinessInfo).mockResolvedValue(baseBusinessInfo as never);

    const caller = appRouter.createCaller(createContext("admin"));
    const result = await caller.businessInfo.update({
      businessName: "The Well Lived Citizen",
      legalEntity: "Well Dressed Citizen LLC",
      city: "Los Angeles",
      serviceArea: "Los Angeles and surrounding areas.",
      primaryPhone: "(323) 433-1350",
      primaryPhoneRaw: "3234331350",
      workingPhone: "(310) 993-0204",
      workingPhoneRaw: "3109930204",
      zellePhone: "(310) 993-0204",
      zellePhoneRaw: "3109930204",
      primaryEmail: "dayna@thewelllivedcitizen.com",
      zelleEmail: "dayna@thewelllivedcitizen.com",
      venmoHandle: "",
      stripePaymentLink: "",
      calendarLink: "",
      instagramMain: "https://instagram.com/thewelllivedcitizen",
      instagramCloset: "https://instagram.com/thewelllivedcloset",
      instagramArchive: "https://instagram.com/welldressedcitizen",
      facebook: "https://facebook.com/thewelllivedcitizen",
      poshmarkUrl: "https://posh.mk/HLUmmsrzq2b",
      ebayUrl: "https://ebay.us/m/cUjlUb",
      responseTime: "Within 24 hours. Text for urgent requests.",
      hoursNote: "By appointment. Text for urgent requests.",
      paymentNote: "Zelle using the email below.",
      homeOrganizationSummary: "Home Organization & Modern Move",
      legacySummary: "Legacy Planning & Inventory Catalog",
      houseCallsSummary: "House Calls",
      resaleSummary: "Curated Resale & Consignment",
    });

    expect(upsertBusinessInfo).toHaveBeenCalledTimes(1);
    expect(result.primaryEmail).toBe("dayna@thewelllivedcitizen.com");
  });

  it("rejects updates from non-admin users", async () => {
    const caller = appRouter.createCaller(createContext("user"));

    await expect(
      caller.businessInfo.update({
        businessName: "The Well Lived Citizen",
        legalEntity: "Well Dressed Citizen LLC",
        city: "Los Angeles",
        serviceArea: "Los Angeles and surrounding areas.",
        primaryPhone: "(323) 433-1350",
        primaryPhoneRaw: "3234331350",
        workingPhone: "(310) 993-0204",
        workingPhoneRaw: "3109930204",
        zellePhone: "(310) 993-0204",
        zellePhoneRaw: "3109930204",
        primaryEmail: "dayna@thewelllivedcitizen.com",
        zelleEmail: "dayna@thewelllivedcitizen.com",
        venmoHandle: "",
        stripePaymentLink: "",
        calendarLink: "",
        instagramMain: "https://instagram.com/thewelllivedcitizen",
        instagramCloset: "https://instagram.com/thewelllivedcloset",
        instagramArchive: "https://instagram.com/welldressedcitizen",
        facebook: "https://facebook.com/thewelllivedcitizen",
        poshmarkUrl: "https://posh.mk/HLUmmsrzq2b",
        ebayUrl: "https://ebay.us/m/cUjlUb",
        responseTime: "Within 24 hours. Text for urgent requests.",
        hoursNote: "By appointment. Text for urgent requests.",
        paymentNote: "Zelle using the email below.",
        homeOrganizationSummary: "Home Organization & Modern Move",
        legacySummary: "Legacy Planning & Inventory Catalog",
        houseCallsSummary: "House Calls",
        resaleSummary: "Curated Resale & Consignment",
      }),
    ).rejects.toMatchObject({
      message: NOT_ADMIN_ERR_MSG,
    });
  });
});

describe("patchRecoveredHtml", () => {
  it("replaces asset paths, rewrites placeholder/internal CTA links, and removes the contact-form interception script", () => {
    const html = `
      <html>
        <body>
          <img src="/assets/logo-black-ihHrkHSC.png" alt="Logo" />
          <img src="/assets/dayna-CD3hSILn.jpg" alt="Dayna" />
          <a href="https://thewelllivedcitizen.com/services/legacy">Legacy</a>
          <a href="https://thewelllivedcitizen.com/contact">Contact</a>
          <a href="mailto:zelleEmail" data-info-href="mailto:zelleEmail">Zelle</a>
          <form action="https://formspree.io/f/xreojkvo" method="POST" id="contactForm"></form>
          <script>
          (function() {
            var form = document.getElementById('contactForm');
            form.addEventListener('submit', function(e) {
              e.preventDefault();
            });
          })();
          </script>
        </body>
      </html>
    `;

    const result = patchRecoveredHtml(html, "contact.html");

    expect(result).toContain("/manus-storage/logo-black-ihHrkHSC_428da26b.png");
    expect(result).toContain("/manus-storage/dayna-CD3hSILn_643b7682.jpg");
    expect(result).toContain('href="/services/legacy"');
    expect(result).toContain('href="/contact"');
    expect(result).toContain('href="mailto:dayna@thewelllivedcitizen.com"');
    expect(result).toContain('action="https://formspree.io/f/xreojkvo" method="POST"');
    expect(result).not.toContain("mailto:zelleEmail");
    expect(result).not.toContain("https://thewelllivedcitizen.com/services/legacy");
    expect(result).not.toContain("https://thewelllivedcitizen.com/contact");
    expect(result).not.toContain("e.preventDefault()");
    expect(result).not.toContain("addEventListener('submit'");
  });
});
