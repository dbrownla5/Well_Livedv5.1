import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { businessInfo, BusinessInfo, InsertBusinessInfo, InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export const BUSINESS_INFO_ID = 1;

const defaultBusinessInfoValues: Omit<InsertBusinessInfo, "id" | "createdAt" | "updatedAt"> = {
  businessName: "The Well Lived Citizen",
  legalEntity: "Well Dressed Citizen LLC",
  city: "Los Angeles",
  serviceArea: "Los Angeles and surrounding areas.",
  primaryPhone: "(323) 433-1350",
  primaryPhoneRaw: "3234331350",
  workingPhone: "(310) 993-0204",
  workingPhoneRaw: "3109930204",
  zellePhone: "(310) 993-0204",
  zellePhoneRaw: "3109930204",
  primaryEmail: "dayna@thewelllivedcitizen.com",
  zelleEmail: "dayna@thewelllivedcitizen.com",
  venmoHandle: "",
  stripePaymentLink: "",
  calendarLink: "",
  instagramMain: "https://instagram.com/thewelllivedcitizen",
  instagramCloset: "https://instagram.com/thewelllivedcloset",
  instagramArchive: "https://instagram.com/welldressedcitizen",
  facebook: "https://facebook.com/thewelllivedcitizen",
  poshmarkUrl: "https://posh.mk/HLUmmsrzq2b",
  ebayUrl: "https://ebay.us/m/cUjlUb",
  responseTime: "Within 24 hours. Text for urgent requests.",
  hoursNote: "By appointment. Text for urgent requests.",
  paymentNote: "Zelle using the email below.",
  homeOrganizationSummary: "Home Organization & Modern Move",
  legacySummary: "Legacy Planning & Inventory Catalog",
  houseCallsSummary: "House Calls",
  resaleSummary: "Curated Resale & Consignment",
};

export type BusinessInfoInput = Partial<Omit<InsertBusinessInfo, "id" | "createdAt" | "updatedAt">>;

function normalizeBusinessInfoInput(input: BusinessInfoInput): Omit<InsertBusinessInfo, "createdAt" | "updatedAt"> {
  return {
    id: BUSINESS_INFO_ID,
    ...defaultBusinessInfoValues,
    ...input,
    businessName: input.businessName ?? defaultBusinessInfoValues.businessName,
    legalEntity: input.legalEntity ?? defaultBusinessInfoValues.legalEntity,
    city: input.city ?? defaultBusinessInfoValues.city,
    serviceArea: input.serviceArea ?? defaultBusinessInfoValues.serviceArea,
    primaryPhone: input.primaryPhone ?? defaultBusinessInfoValues.primaryPhone,
    primaryPhoneRaw: input.primaryPhoneRaw ?? defaultBusinessInfoValues.primaryPhoneRaw,
    workingPhone: input.workingPhone ?? defaultBusinessInfoValues.workingPhone,
    workingPhoneRaw: input.workingPhoneRaw ?? defaultBusinessInfoValues.workingPhoneRaw,
    zellePhone: input.zellePhone ?? defaultBusinessInfoValues.zellePhone,
    zellePhoneRaw: input.zellePhoneRaw ?? defaultBusinessInfoValues.zellePhoneRaw,
    primaryEmail: input.primaryEmail ?? defaultBusinessInfoValues.primaryEmail,
    zelleEmail: input.zelleEmail ?? defaultBusinessInfoValues.zelleEmail,
    venmoHandle: input.venmoHandle ?? defaultBusinessInfoValues.venmoHandle,
    stripePaymentLink: input.stripePaymentLink ?? defaultBusinessInfoValues.stripePaymentLink,
    calendarLink: input.calendarLink ?? defaultBusinessInfoValues.calendarLink,
    instagramMain: input.instagramMain ?? defaultBusinessInfoValues.instagramMain,
    instagramCloset: input.instagramCloset ?? defaultBusinessInfoValues.instagramCloset,
    instagramArchive: input.instagramArchive ?? defaultBusinessInfoValues.instagramArchive,
    facebook: input.facebook ?? defaultBusinessInfoValues.facebook,
    poshmarkUrl: input.poshmarkUrl ?? defaultBusinessInfoValues.poshmarkUrl,
    ebayUrl: input.ebayUrl ?? defaultBusinessInfoValues.ebayUrl,
    responseTime: input.responseTime ?? defaultBusinessInfoValues.responseTime,
    hoursNote: input.hoursNote ?? defaultBusinessInfoValues.hoursNote,
    paymentNote: input.paymentNote ?? defaultBusinessInfoValues.paymentNote,
    homeOrganizationSummary: input.homeOrganizationSummary ?? defaultBusinessInfoValues.homeOrganizationSummary,
    legacySummary: input.legacySummary ?? defaultBusinessInfoValues.legacySummary,
    houseCallsSummary: input.houseCallsSummary ?? defaultBusinessInfoValues.houseCallsSummary,
    resaleSummary: input.resaleSummary ?? defaultBusinessInfoValues.resaleSummary,
  };
}

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getBusinessInfo(): Promise<BusinessInfo | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get business info: database not available");
    return undefined;
  }

  const result = await db.select().from(businessInfo).where(eq(businessInfo.id, BUSINESS_INFO_ID)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertBusinessInfo(input: BusinessInfoInput): Promise<BusinessInfoInput> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert business info: database not available");
    return normalizeBusinessInfoInput(input);
  }

  const values = normalizeBusinessInfoInput(input);
  const { id: _id, ...updateSet } = values;

  await db.insert(businessInfo).values(values).onDuplicateKeyUpdate({
    set: updateSet,
  });

  return values;
}
