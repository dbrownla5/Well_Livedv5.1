import fs from "node:fs/promises";
import path from "node:path";
import express, { type Express } from "express";

const recoveredSiteDir = "/home/ubuntu/upload";
const logoStorageUrl = "/manus-storage/logo-black-ihHrkHSC_428da26b.png";
const daynaStorageUrl = "/manus-storage/dayna-CD3hSILn_643b7682.jpg";

const publicPageMap = new Map<string, string>([
  ["/", "index.html"],
  ["/index.html", "index.html"],
  ["/about", "about.html"],
  ["/about.html", "about.html"],
  ["/services", "services.html"],
  ["/services.html", "services.html"],
  ["/services/home-organization", "home-organization.html"],
  ["/services/home-organization.html", "home-organization.html"],
  ["/services/house-calls", "house-calls.html"],
  ["/services/house-calls.html", "house-calls.html"],
  ["/services/legacy", "legacy.html"],
  ["/services/legacy.html", "legacy.html"],
  ["/services/resale", "resale.html"],
  ["/services/resale.html", "resale.html"],
  ["/pricing", "pricing.html"],
  ["/pricing.html", "pricing.html"],
  ["/contact", "contact.html"],
  ["/contact.html", "contact.html"],
]);

export function patchRecoveredHtml(html: string, filename: string) {
  let patched = html
    .replaceAll("/assets/logo-black-ihHrkHSC.png", logoStorageUrl)
    .replaceAll("logo-black-ihHrkHSC.png", logoStorageUrl)
    .replaceAll("/assets/dayna-CD3hSILn.jpg", daynaStorageUrl)
    .replaceAll("dayna-CD3hSILn.jpg", daynaStorageUrl)
    .replaceAll("https://thewelllivedcitizen.com/services/home-organization", "/services/home-organization")
    .replaceAll("https://thewelllivedcitizen.com/services/house-calls", "/services/house-calls")
    .replaceAll("https://thewelllivedcitizen.com/services/legacy", "/services/legacy")
    .replaceAll("https://thewelllivedcitizen.com/services/resale", "/services/resale")
    .replaceAll("https://thewelllivedcitizen.com/services", "/services")
    .replaceAll("https://thewelllivedcitizen.com/pricing", "/pricing")
    .replaceAll("https://thewelllivedcitizen.com/about", "/about")
    .replaceAll("https://thewelllivedcitizen.com/contact", "/contact")
    .replaceAll("https://thewelllivedcitizen.com", "/")
    .replaceAll("mailto:zelleEmail", "mailto:dayna@thewelllivedcitizen.com");

  if (filename === "contact.html") {
    patched = patched.replace(
      /<script>\s*\(function\(\) \{[\s\S]*?form\.addEventListener\('submit',[\s\S]*?\}\)\(\);\s*<\/script>/,
      "",
    );
  }

  return patched;
}

async function sendRecoveredPage(res: express.Response, filename: string) {
  const filePath = path.join(recoveredSiteDir, filename);
  const html = await fs.readFile(filePath, "utf8");
  res.status(200).type("html").send(patchRecoveredHtml(html, filename));
}

export function registerRecoveredPublicSite(app: Express) {
  app.get("/assets/style-Dbo472dq.css", (_req, res) => {
    res.sendFile(path.join(recoveredSiteDir, "style-Dbo472dq.css"));
  });

  app.get("/info-loader.js", (_req, res) => {
    res.type("application/javascript").sendFile(path.join(recoveredSiteDir, "info-loader.js"));
  });

  app.get("/assets/info-loader.js", (_req, res) => {
    res.type("application/javascript").sendFile(path.join(recoveredSiteDir, "info-loader.js"));
  });

  Array.from(publicPageMap.entries()).forEach(([routePath, filename]) => {
    app.get(routePath, async (_req, res, next) => {
      try {
        await sendRecoveredPage(res, filename);
      } catch (error) {
        next(error);
      }
    });
  });
}

export const recoveredPublicRoutes = Array.from(publicPageMap.keys());
