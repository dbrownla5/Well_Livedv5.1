import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const businessInfo = mysqlTable("businessInfo", {
  id: int("id").autoincrement().primaryKey(),
  businessName: varchar("businessName", { length: 255 }).notNull().default("The Well Lived Citizen"),
  legalEntity: varchar("legalEntity", { length: 255 }).notNull().default("Well Dressed Citizen LLC"),
  city: varchar("city", { length: 255 }).notNull().default("Los Angeles"),
  serviceArea: text("serviceArea").notNull(),
  primaryPhone: varchar("primaryPhone", { length: 32 }).notNull(),
  primaryPhoneRaw: varchar("primaryPhoneRaw", { length: 32 }).notNull(),
  workingPhone: varchar("workingPhone", { length: 32 }).notNull(),
  workingPhoneRaw: varchar("workingPhoneRaw", { length: 32 }).notNull(),
  zellePhone: varchar("zellePhone", { length: 32 }).notNull(),
  zellePhoneRaw: varchar("zellePhoneRaw", { length: 32 }).notNull(),
  primaryEmail: varchar("primaryEmail", { length: 320 }).notNull(),
  zelleEmail: varchar("zelleEmail", { length: 320 }).notNull(),
  venmoHandle: varchar("venmoHandle", { length: 255 }).notNull(),
  stripePaymentLink: text("stripePaymentLink").notNull(),
  calendarLink: text("calendarLink").notNull(),
  instagramMain: text("instagramMain").notNull(),
  instagramCloset: text("instagramCloset").notNull(),
  instagramArchive: text("instagramArchive").notNull(),
  facebook: text("facebook").notNull(),
  poshmarkUrl: text("poshmarkUrl").notNull(),
  ebayUrl: text("ebayUrl").notNull(),
  responseTime: text("responseTime").notNull(),
  hoursNote: text("hoursNote").notNull(),
  paymentNote: text("paymentNote").notNull(),
  homeOrganizationSummary: text("homeOrganizationSummary").notNull(),
  legacySummary: text("legacySummary").notNull(),
  houseCallsSummary: text("houseCallsSummary").notNull(),
  resaleSummary: text("resaleSummary").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type BusinessInfo = typeof businessInfo.$inferSelect;
export type InsertBusinessInfo = typeof businessInfo.$inferInsert;
