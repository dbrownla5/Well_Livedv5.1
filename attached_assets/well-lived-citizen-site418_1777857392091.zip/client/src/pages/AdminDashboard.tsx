import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { FormEvent, useEffect, useState } from "react";

type BusinessInfoForm = {
  businessName: string;
  legalEntity: string;
  city: string;
  serviceArea: string;
  primaryPhone: string;
  primaryPhoneRaw: string;
  workingPhone: string;
  workingPhoneRaw: string;
  zellePhone: string;
  zellePhoneRaw: string;
  primaryEmail: string;
  zelleEmail: string;
  venmoHandle: string;
  stripePaymentLink: string;
  calendarLink: string;
  instagramMain: string;
  instagramCloset: string;
  instagramArchive: string;
  facebook: string;
  poshmarkUrl: string;
  ebayUrl: string;
  responseTime: string;
  hoursNote: string;
  paymentNote: string;
  homeOrganizationSummary: string;
  legacySummary: string;
  houseCallsSummary: string;
  resaleSummary: string;
};

const emptyForm: BusinessInfoForm = {
  businessName: "",
  legalEntity: "",
  city: "",
  serviceArea: "",
  primaryPhone: "",
  primaryPhoneRaw: "",
  workingPhone: "",
  workingPhoneRaw: "",
  zellePhone: "",
  zellePhoneRaw: "",
  primaryEmail: "",
  zelleEmail: "",
  venmoHandle: "",
  stripePaymentLink: "",
  calendarLink: "",
  instagramMain: "",
  instagramCloset: "",
  instagramArchive: "",
  facebook: "",
  poshmarkUrl: "",
  ebayUrl: "",
  responseTime: "",
  hoursNote: "",
  paymentNote: "",
  homeOrganizationSummary: "",
  legacySummary: "",
  houseCallsSummary: "",
  resaleSummary: "",
};

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: "text" | "email" | "url";
}) {
  return (
    <label className="block space-y-2">
      <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={event => onChange(event.target.value)}
        className="min-h-11 w-full border border-input bg-card px-3 py-2 text-sm text-foreground outline-none transition-colors focus:border-ring"
      />
    </label>
  );
}

function TextAreaField({
  label,
  value,
  onChange,
  rows = 4,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows?: number;
}) {
  return (
    <label className="block space-y-2">
      <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
      <textarea
        rows={rows}
        value={value}
        onChange={event => onChange(event.target.value)}
        className="min-h-24 w-full border border-input bg-card px-3 py-2 text-sm leading-6 text-foreground outline-none transition-colors focus:border-ring"
      />
    </label>
  );
}

export default function AdminDashboard() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.businessInfo.get.useQuery();
  const updateBusinessInfo = trpc.businessInfo.update.useMutation({
    onSuccess: async () => {
      await utils.businessInfo.get.invalidate();
    },
  });
  const [form, setForm] = useState<BusinessInfoForm>(emptyForm);

  useEffect(() => {
    if (!data) return;

    setForm({
      businessName: data.businessName ?? "",
      legalEntity: data.legalEntity ?? "",
      city: data.city ?? "",
      serviceArea: data.serviceArea ?? "",
      primaryPhone: data.primaryPhone ?? "",
      primaryPhoneRaw: data.primaryPhoneRaw ?? "",
      workingPhone: data.workingPhone ?? "",
      workingPhoneRaw: data.workingPhoneRaw ?? "",
      zellePhone: data.zellePhone ?? "",
      zellePhoneRaw: data.zellePhoneRaw ?? "",
      primaryEmail: data.primaryEmail ?? "",
      zelleEmail: data.zelleEmail ?? "",
      venmoHandle: data.venmoHandle ?? "",
      stripePaymentLink: data.stripePaymentLink ?? "",
      calendarLink: data.calendarLink ?? "",
      instagramMain: data.instagramMain ?? "",
      instagramCloset: data.instagramCloset ?? "",
      instagramArchive: data.instagramArchive ?? "",
      facebook: data.facebook ?? "",
      poshmarkUrl: data.poshmarkUrl ?? "",
      ebayUrl: data.ebayUrl ?? "",
      responseTime: data.responseTime ?? "",
      hoursNote: data.hoursNote ?? "",
      paymentNote: data.paymentNote ?? "",
      homeOrganizationSummary: data.homeOrganizationSummary ?? "",
      legacySummary: data.legacySummary ?? "",
      houseCallsSummary: data.houseCallsSummary ?? "",
      resaleSummary: data.resaleSummary ?? "",
    });
  }, [data]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await updateBusinessInfo.mutateAsync(form);
  }

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-6xl space-y-6">
        <section className="border border-border bg-card p-5 sm:p-6">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-muted-foreground">Single source of truth</p>
          <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_260px] lg:items-end">
            <div>
              <h1 className="text-3xl font-semibold tracking-[-0.03em] text-foreground">Business data</h1>
              <p className="mt-3 max-w-3xl text-sm leading-7 text-muted-foreground">
                This panel controls the fields returned by the public business-info endpoint and keeps the owner record organized in one place.
              </p>
            </div>
            <div className="border border-border bg-background p-4 text-sm leading-7 text-muted-foreground">
              <p>
                <span className="font-semibold text-foreground">Public site line:</span> 323-433-1350
              </p>
              <p>
                <span className="font-semibold text-foreground">Working line:</span> 310-993-0204
              </p>
            </div>
          </div>
        </section>

        {isLoading ? (
          <section className="border border-border bg-card p-6 text-sm text-muted-foreground">Loading business data…</section>
        ) : (
          <form className="space-y-6" onSubmit={handleSubmit}>
            <section className="border border-border bg-card p-5 sm:p-6">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                <Field label="Business name" value={form.businessName} onChange={value => setForm(current => ({ ...current, businessName: value }))} />
                <Field label="Legal entity" value={form.legalEntity} onChange={value => setForm(current => ({ ...current, legalEntity: value }))} />
                <Field label="City" value={form.city} onChange={value => setForm(current => ({ ...current, city: value }))} />
                <Field label="Primary phone display" value={form.primaryPhone} onChange={value => setForm(current => ({ ...current, primaryPhone: value }))} />
                <Field label="Primary phone raw" value={form.primaryPhoneRaw} onChange={value => setForm(current => ({ ...current, primaryPhoneRaw: value }))} />
                <Field label="Working phone display" value={form.workingPhone} onChange={value => setForm(current => ({ ...current, workingPhone: value }))} />
                <Field label="Working phone raw" value={form.workingPhoneRaw} onChange={value => setForm(current => ({ ...current, workingPhoneRaw: value }))} />
                <Field label="Zelle phone display" value={form.zellePhone} onChange={value => setForm(current => ({ ...current, zellePhone: value }))} />
                <Field label="Zelle phone raw" value={form.zellePhoneRaw} onChange={value => setForm(current => ({ ...current, zellePhoneRaw: value }))} />
                <Field label="Primary email" type="email" value={form.primaryEmail} onChange={value => setForm(current => ({ ...current, primaryEmail: value }))} />
                <Field label="Zelle email" type="email" value={form.zelleEmail} onChange={value => setForm(current => ({ ...current, zelleEmail: value }))} />
                <Field label="Venmo handle" value={form.venmoHandle} onChange={value => setForm(current => ({ ...current, venmoHandle: value }))} />
              </div>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <TextAreaField label="Service area" value={form.serviceArea} onChange={value => setForm(current => ({ ...current, serviceArea: value }))} rows={3} />
                <TextAreaField label="Response time" value={form.responseTime} onChange={value => setForm(current => ({ ...current, responseTime: value }))} rows={3} />
              </div>
            </section>

            <section className="border border-border bg-card p-5 sm:p-6">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                <Field label="Instagram main" type="url" value={form.instagramMain} onChange={value => setForm(current => ({ ...current, instagramMain: value }))} />
                <Field label="Instagram closet" type="url" value={form.instagramCloset} onChange={value => setForm(current => ({ ...current, instagramCloset: value }))} />
                <Field label="Instagram archive" type="url" value={form.instagramArchive} onChange={value => setForm(current => ({ ...current, instagramArchive: value }))} />
                <Field label="Facebook" type="url" value={form.facebook} onChange={value => setForm(current => ({ ...current, facebook: value }))} />
                <Field label="Poshmark" type="url" value={form.poshmarkUrl} onChange={value => setForm(current => ({ ...current, poshmarkUrl: value }))} />
                <Field label="eBay" type="url" value={form.ebayUrl} onChange={value => setForm(current => ({ ...current, ebayUrl: value }))} />
                <Field label="Calendar link" type="url" value={form.calendarLink} onChange={value => setForm(current => ({ ...current, calendarLink: value }))} />
                <Field label="Stripe payment link" type="url" value={form.stripePaymentLink} onChange={value => setForm(current => ({ ...current, stripePaymentLink: value }))} />
              </div>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <TextAreaField label="Hours note" value={form.hoursNote} onChange={value => setForm(current => ({ ...current, hoursNote: value }))} rows={3} />
                <TextAreaField label="Payment note" value={form.paymentNote} onChange={value => setForm(current => ({ ...current, paymentNote: value }))} rows={3} />
              </div>
            </section>

            <section className="border border-border bg-card p-5 sm:p-6">
              <div className="grid gap-4 md:grid-cols-2">
                <TextAreaField label="Home organization summary" value={form.homeOrganizationSummary} onChange={value => setForm(current => ({ ...current, homeOrganizationSummary: value }))} />
                <TextAreaField label="Legacy summary" value={form.legacySummary} onChange={value => setForm(current => ({ ...current, legacySummary: value }))} />
                <TextAreaField label="House calls summary" value={form.houseCallsSummary} onChange={value => setForm(current => ({ ...current, houseCallsSummary: value }))} />
                <TextAreaField label="Resale summary" value={form.resaleSummary} onChange={value => setForm(current => ({ ...current, resaleSummary: value }))} />
              </div>
            </section>

            <section className="flex flex-col gap-3 border border-border bg-card p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
              <div className="text-sm leading-7 text-muted-foreground">
                {updateBusinessInfo.isSuccess ? "Saved. The public API now serves the latest version of this record." : "Save changes after any approved fact update so the dashboard stays current."}
              </div>
              <Button
                type="submit"
                className="!rounded-none border border-primary bg-primary px-6 text-primary-foreground shadow-none hover:bg-primary/95"
                disabled={updateBusinessInfo.isPending}
              >
                {updateBusinessInfo.isPending ? "Saving…" : "Save business data"}
              </Button>
            </section>
          </form>
        )}
      </div>
    </DashboardLayout>
  );
}
