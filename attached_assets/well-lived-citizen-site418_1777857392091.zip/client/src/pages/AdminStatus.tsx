import DashboardLayout from "@/components/DashboardLayout";

const pageStatusRows = [
  {
    route: "/",
    sourceFile: "index.html",
    title: "The Well Lived Citizen — Los Angeles",
    notes: "Recovered homepage is serving from the local recovery set.",
  },
  {
    route: "/about",
    sourceFile: "about.html",
    title: "About Dayna Brown",
    notes: "Portrait asset served from managed storage.",
  },
  {
    route: "/services",
    sourceFile: "services.html",
    title: "Services & Pricing",
    notes: "Primary service index page is routed through the recovered static layer.",
  },
  {
    route: "/services/home-organization",
    sourceFile: "home-organization.html",
    title: "Home Organization & Modern Move",
    notes: "Recovered service detail page is available on the new server route.",
  },
  {
    route: "/services/house-calls",
    sourceFile: "house-calls.html",
    title: "House Calls",
    notes: "Direct 323 tel links remain in place for the public site.",
  },
  {
    route: "/services/legacy",
    sourceFile: "legacy.html",
    title: "Legacy Planning & Inventory Catalog",
    notes: "Recovered static content is mounted without copy changes.",
  },
  {
    route: "/services/resale",
    sourceFile: "resale.html",
    title: "Curated Resale & Consignment",
    notes: "Closet social and resale outbound links remain direct href links.",
  },
  {
    route: "/pricing",
    sourceFile: "pricing.html",
    title: "Pricing",
    notes: "Zelle email fields can be managed from the owner dashboard.",
  },
  {
    route: "/contact",
    sourceFile: "contact.html",
    title: "Get in Touch",
    notes: "Form action is preserved for direct Formspree POST handling.",
  },
];

export default function AdminStatus() {
  return (
    <DashboardLayout>
      <div className="mx-auto max-w-6xl space-y-6">
        <section className="border border-border bg-card p-5 sm:p-6">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-muted-foreground">Public site inventory</p>
          <h1 className="mt-4 text-3xl font-semibold tracking-[-0.03em] text-foreground">Page status overview</h1>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-muted-foreground">
            This view records the public routes being served from the recovered source set and highlights the operational details that matter during review and handoff.
          </p>
        </section>

        <section className="border border-border bg-card">
          <div className="hidden grid-cols-[minmax(0,180px)_minmax(0,220px)_minmax(0,260px)_minmax(0,1fr)] border-b border-border bg-background px-5 py-4 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground md:grid">
            <div>Route</div>
            <div>Source file</div>
            <div>Title</div>
            <div>Notes</div>
          </div>

          <div className="divide-y divide-border">
            {pageStatusRows.map(row => (
              <article key={row.route} className="grid gap-4 px-5 py-5 md:grid-cols-[minmax(0,180px)_minmax(0,220px)_minmax(0,260px)_minmax(0,1fr)] md:items-start">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground md:hidden">Route</div>
                  <div className="mt-1 text-sm font-medium text-foreground">{row.route}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground md:hidden">Source file</div>
                  <div className="mt-1 text-sm text-foreground">{row.sourceFile}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground md:hidden">Title</div>
                  <div className="mt-1 text-sm text-foreground">{row.title}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground md:hidden">Notes</div>
                  <div className="mt-1 text-sm leading-7 text-muted-foreground">{row.notes}</div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-3">
          <div className="border border-border bg-card p-5 text-sm leading-7 text-muted-foreground">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Storage assets</p>
            <p className="mt-3 text-foreground">Logo and portrait are served from managed storage, not from the project directory.</p>
          </div>
          <div className="border border-border bg-card p-5 text-sm leading-7 text-muted-foreground">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">API dependency</p>
            <p className="mt-3 text-foreground">`info-loader.js` reads `/api/business-info`, which is now backed by the database singleton.</p>
          </div>
          <div className="border border-border bg-card p-5 text-sm leading-7 text-muted-foreground">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Contact handling</p>
            <p className="mt-3 text-foreground">The contact page is configured for direct Formspree submission rather than a JavaScript interception layer.</p>
          </div>
        </section>
      </div>
    </DashboardLayout>
  );
}
