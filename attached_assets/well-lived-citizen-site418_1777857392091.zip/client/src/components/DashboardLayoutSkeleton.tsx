export function DashboardLayoutSkeleton() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex min-h-screen">
        <aside className="hidden w-[280px] border-r border-border bg-sidebar md:block">
          <div className="border-b border-sidebar-border px-4 py-4">
            <div className="h-3 w-32 bg-muted" />
            <div className="mt-3 h-4 w-40 bg-muted" />
          </div>
          <div className="space-y-3 px-4 py-4">
            <div className="h-11 w-full border border-sidebar-border bg-background" />
            <div className="h-11 w-full border border-sidebar-border bg-background" />
          </div>
          <div className="mt-auto border-t border-sidebar-border px-4 py-4">
            <div className="h-16 w-full border border-sidebar-border bg-background" />
            <div className="mt-3 h-11 w-full border border-sidebar-border bg-background" />
          </div>
        </aside>
        <main className="flex-1 p-4 sm:p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            <div className="border border-border bg-card p-6">
              <div className="h-3 w-40 bg-muted" />
              <div className="mt-4 h-10 w-80 max-w-full bg-muted" />
              <div className="mt-4 h-5 w-full max-w-3xl bg-muted" />
              <div className="mt-2 h-5 w-full max-w-2xl bg-muted" />
            </div>
            <div className="border border-border bg-card p-6">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 9 }).map((_, index) => (
                  <div key={index} className="space-y-2">
                    <div className="h-3 w-28 bg-muted" />
                    <div className="h-11 border border-input bg-background" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
